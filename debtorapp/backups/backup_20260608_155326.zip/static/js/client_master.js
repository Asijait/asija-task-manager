document.addEventListener('DOMContentLoaded', function() {
    console.log("Client Master Module Initialized");
    
    const flashMessages = document.querySelectorAll('.flash-message');
    flashMessages.forEach(msg => {
        setTimeout(() => {
            msg.style.opacity = '0';
            setTimeout(() => msg.remove(), 500);
        }, 2000);
    });

    const showFormButton = document.getElementById('showClientFormBtn');
    const hideFormButton = document.getElementById('hideClientFormBtn');
    const formSection = document.getElementById('clientFormSection');

    if (showFormButton && formSection) {
        showFormButton.addEventListener('click', () => {
            formSection.hidden = false;
            const firstInput = formSection.querySelector('input');
            if (firstInput) firstInput.focus();
        });
    }

    if (hideFormButton && formSection) {
        hideFormButton.addEventListener('click', () => {
            formSection.hidden = true;
        });
    }

    const groupSelect = document.getElementById('clientGroupSelect');
    const groupInput = document.getElementById('clientGroupInput');
    const groupOptions = document.getElementById('clientGroupOptions');
    const crpInput = document.getElementById('clientCrpInput');
    const allowAnotherCrp = document.getElementById('allowAnotherCrp');
    const groupCrpData = document.getElementById('groupCrpData');
    let groupCrpMap = {};

    if (groupCrpData) {
        try {
            groupCrpMap = JSON.parse(groupCrpData.textContent || '{}');
        } catch (error) {
            groupCrpMap = {};
        }
    }

    function primaryCrpForGroup(groupName) {
        const crpList = groupCrpMap[(groupName || '').trim()] || [];
        return crpList[0] || '';
    }

    function syncCrpFromGroup(groupField, crpField, allowCheckbox) {
        if (!groupField || !crpField || !allowCheckbox) return;

        const primaryCrp = primaryCrpForGroup(groupField.value);
        const shouldLockCrp = Boolean(primaryCrp) && !allowCheckbox.checked;

        if (shouldLockCrp) crpField.value = primaryCrp;
        crpField.readOnly = shouldLockCrp;
        crpField.classList.toggle('is-readonly', shouldLockCrp);
        crpField.placeholder = primaryCrp ? 'Primary CRP from group' : 'CRP of Group';
    }

    function setupSearchableGroupSelect(select, input, options, onSelect) {
        if (!select || !input || !options) return;

        function filterOptions() {
            const searchText = input.value.trim().toLowerCase();
            options.querySelectorAll('.searchable-option').forEach(option => {
                option.style.display = option.textContent.toLowerCase().includes(searchText) ? "" : "none";
            });
        }

        function openOptions() {
            options.classList.add('is-open');
            filterOptions();
        }

        function closeOptions() {
            options.classList.remove('is-open');
        }

        input.addEventListener('focus', openOptions);
        input.addEventListener('click', openOptions);
        input.addEventListener('input', openOptions);

        options.querySelectorAll('.searchable-option').forEach(option => {
            option.addEventListener('click', () => {
                input.value = option.dataset.value || option.textContent.trim();
                if (onSelect) onSelect();
                closeOptions();
            });
        });

        document.addEventListener('click', event => {
            if (!select.contains(event.target)) closeOptions();
        });
    }

    setupSearchableGroupSelect(groupSelect, groupInput, groupOptions, () => {
        syncCrpFromGroup(groupInput, crpInput, allowAnotherCrp);
    });

    if (groupInput) {
        groupInput.addEventListener('input', () => {
            syncCrpFromGroup(groupInput, crpInput, allowAnotherCrp);
        });
    }

    if (allowAnotherCrp) {
        allowAnotherCrp.addEventListener('change', () => {
            syncCrpFromGroup(groupInput, crpInput, allowAnotherCrp);
            if (allowAnotherCrp.checked && crpInput) crpInput.focus();
        });
    }

    const modal = document.getElementById('clientEditModal');
    const closeButton = document.getElementById('clientEditClose');
    const cancelButton = document.getElementById('clientEditCancel');

    function setValue(id, value) {
        const input = document.getElementById(id);
        if (input) input.value = value || '';
    }

    function openModal(row) {
        setValue('editClientId', row.dataset.clientId);
        setValue('editClientName', row.dataset.clientName);
        setValue('editClientGroup', row.dataset.clientGroup);
        setValue('editClientCategory', row.dataset.clientCategory);
        setValue('editCrpOfGroup', row.dataset.crpOfGroup);
        setValue('editRefferedBy', row.dataset.refferedBy);
        setValue('editWhatappGroup', row.dataset.whatappGroup);
        setValue('editPhone', row.dataset.phone);
        setValue('editEmail', row.dataset.email);
        setValue('editGstin', row.dataset.gstin);
        const editAllowAnotherCrp = document.getElementById('editAllowAnotherCrp');
        const primaryCrp = primaryCrpForGroup(row.dataset.clientGroup);
        if (editAllowAnotherCrp) {
            editAllowAnotherCrp.checked = Boolean(row.dataset.crpOfGroup && primaryCrp && row.dataset.crpOfGroup !== primaryCrp);
        }
        syncCrpFromGroup(
            document.getElementById('editClientGroup'),
            document.getElementById('editCrpOfGroup'),
            editAllowAnotherCrp
        );
        if (editAllowAnotherCrp && editAllowAnotherCrp.checked) {
            setValue('editCrpOfGroup', row.dataset.crpOfGroup);
        }
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
    }

    function closeModal() {
        if (!modal) return;
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
    }

    document.querySelectorAll('.client-edit-btn').forEach(button => {
        button.addEventListener('click', () => {
            const row = button.closest('tr');
            if (row && modal) openModal(row);
        });
    });

    if (closeButton) closeButton.addEventListener('click', closeModal);
    if (cancelButton) cancelButton.addEventListener('click', closeModal);
    if (modal) {
        modal.addEventListener('click', event => {
            if (event.target === modal) closeModal();
        });
    }

    const editClientGroup = document.getElementById('editClientGroup');
    const editCrpOfGroup = document.getElementById('editCrpOfGroup');
    const editAllowAnotherCrp = document.getElementById('editAllowAnotherCrp');
    const editClientGroupSelect = document.getElementById('editClientGroupSelect');
    const editClientGroupOptions = document.getElementById('editClientGroupOptions');

    setupSearchableGroupSelect(editClientGroupSelect, editClientGroup, editClientGroupOptions, () => {
        syncCrpFromGroup(editClientGroup, editCrpOfGroup, editAllowAnotherCrp);
    });

    if (editClientGroup) {
        editClientGroup.addEventListener('input', () => {
            syncCrpFromGroup(editClientGroup, editCrpOfGroup, editAllowAnotherCrp);
        });
    }

    if (editAllowAnotherCrp) {
        editAllowAnotherCrp.addEventListener('change', () => {
            syncCrpFromGroup(editClientGroup, editCrpOfGroup, editAllowAnotherCrp);
            if (editAllowAnotherCrp.checked && editCrpOfGroup) editCrpOfGroup.focus();
        });
    }

    document.addEventListener('keydown', event => {
        if (event.key === 'Escape') closeModal();
    });

    const clientTable = document.getElementById('clientTable');
    if (!clientTable) return;

    const clientRows = Array.from(clientTable.querySelectorAll('tbody tr'));
    const filterableColumns = [1, 2, 3, 4, 5];
    const activeFilters = {};
    const quickSearch = document.getElementById('clientQuickSearch');

    function filterClientTable() {
        const searchText = quickSearch ? quickSearch.value.trim().toLowerCase() : '';

        clientRows.forEach(row => {
            let isVisible = true;
            filterableColumns.forEach(cellIndex => {
                const selectedValues = activeFilters[cellIndex];
                if (!selectedValues || selectedValues.size === 0) return;

                const cellText = row.cells[cellIndex].textContent.trim();
                if (!selectedValues.has(cellText)) isVisible = false;
            });

            if (searchText && !row.textContent.toLowerCase().includes(searchText)) {
                isVisible = false;
            }

            row.style.display = isVisible ? "" : "none";
        });
    }

    if (quickSearch) {
        quickSearch.addEventListener('input', filterClientTable);
    }

    function updateFilterButton(button, cellIndex) {
        const selectedValues = activeFilters[cellIndex];
        const hasFilter = selectedValues && selectedValues.size > 0;
        button.classList.toggle('is-filtered', hasFilter);
        button.title = hasFilter ? `${selectedValues.size} selected` : 'Filter';
    }

    function setVisibleOptions(menu, searchText) {
        const term = searchText.trim().toLowerCase();
        menu.querySelectorAll('.filter-option').forEach(option => {
            option.style.display = option.textContent.toLowerCase().includes(term) ? "" : "none";
        });
    }

    function positionFilterMenu(button, menu) {
        const rect = button.getBoundingClientRect();
        const width = Math.min(300, window.innerWidth - 16);
        const left = Math.min(Math.max(8, rect.left), window.innerWidth - width - 8);
        const top = Math.min(rect.bottom + 6, window.innerHeight - 90);

        menu.style.width = `${width}px`;
        menu.style.left = `${left}px`;
        menu.style.top = `${top}px`;
    }

    function buildClientFilter(th, cellIndex) {
        const label = th.textContent.trim();
        th.textContent = "";

        const wrapper = document.createElement('div');
        wrapper.className = 'th-filter';

        const labelSpan = document.createElement('span');
        labelSpan.className = 'th-label';
        labelSpan.textContent = label;

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'filter-toggle';
        button.textContent = 'v';
        button.title = 'Filter';

        const menu = document.createElement('div');
        menu.className = 'filter-menu';

        const search = document.createElement('input');
        search.type = 'text';
        search.className = 'filter-search';
        search.placeholder = 'Search';

        const actions = document.createElement('div');
        actions.className = 'filter-actions';

        const selectAll = document.createElement('button');
        selectAll.type = 'button';
        selectAll.textContent = 'Select All';

        const clear = document.createElement('button');
        clear.type = 'button';
        clear.textContent = 'Clear';

        const ok = document.createElement('button');
        ok.type = 'button';
        ok.textContent = 'OK';

        const options = document.createElement('div');
        options.className = 'filter-options';

        const values = [...new Set(clientRows.map(row => row.cells[cellIndex].textContent.trim()))]
            .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));

        values.forEach(value => {
            const option = document.createElement('label');
            option.className = 'filter-option';

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.value = value;

            const text = document.createElement('span');
            text.textContent = value || '(blank)';

            option.appendChild(checkbox);
            option.appendChild(text);
            options.appendChild(option);

        });

        selectAll.addEventListener('click', () => {
            options.querySelectorAll('.filter-option').forEach(option => {
                if (option.style.display !== 'none') {
                    option.querySelector('input').checked = true;
                }
            });
        });

        clear.addEventListener('click', () => {
            options.querySelectorAll('input').forEach(input => {
                input.checked = false;
            });
            activeFilters[cellIndex] = new Set();
        });

        ok.addEventListener('click', () => {
            activeFilters[cellIndex] = new Set(
                Array.from(options.querySelectorAll('input:checked')).map(input => input.value)
            );
            updateFilterButton(button, cellIndex);
            filterClientTable();
            menu.classList.remove('is-open');
        });

        search.addEventListener('input', () => setVisibleOptions(menu, search.value));

        button.addEventListener('click', event => {
            event.stopPropagation();
            document.querySelectorAll('.filter-menu.is-open').forEach(openMenu => {
                if (openMenu !== menu) openMenu.classList.remove('is-open');
            });
            menu.classList.toggle('is-open');
            if (menu.classList.contains('is-open')) {
                positionFilterMenu(button, menu);
                search.focus();
            }
        });

        menu.addEventListener('click', event => event.stopPropagation());

        actions.appendChild(selectAll);
        actions.appendChild(clear);
        actions.appendChild(ok);
        menu.appendChild(search);
        menu.appendChild(actions);
        menu.appendChild(options);
        wrapper.appendChild(labelSpan);
        wrapper.appendChild(button);
        wrapper.appendChild(menu);
        th.appendChild(wrapper);
    }

    filterableColumns.forEach(cellIndex => {
        const th = clientTable.tHead.rows[0].cells[cellIndex];
        if (th) buildClientFilter(th, cellIndex);
    });

    document.addEventListener('click', () => {
        document.querySelectorAll('.filter-menu.is-open').forEach(menu => {
            menu.classList.remove('is-open');
        });
    });

    window.addEventListener('resize', () => {
        document.querySelectorAll('.filter-menu.is-open').forEach(menu => {
            menu.classList.remove('is-open');
        });
    });

    document.querySelector('main')?.addEventListener('scroll', () => {
        document.querySelectorAll('.filter-menu.is-open').forEach(menu => {
            menu.classList.remove('is-open');
        });
    });
});
