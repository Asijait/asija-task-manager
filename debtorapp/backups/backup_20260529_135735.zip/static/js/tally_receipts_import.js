document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('tallyReceiptForm');
    const dateInput = document.getElementById('tallyReceiptDate');
    const clearButton = document.getElementById('clearTallyDate');
    const statusBox = document.getElementById('tallyStatus');
    const metaBox = document.getElementById('tallyMeta');
    const rowsBody = document.getElementById('tallyReceiptRows');
    const previewUrl = document.body.dataset.previewUrl;

    function setStatus(message, isError = false) {
        statusBox.textContent = message;
        statusBox.classList.toggle('is-error', isError);
    }

    function formatAmount(value) {
        const amount = Number(value || 0);
        return amount.toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    function setText(id, value) {
        const element = document.getElementById(id);
        if (element) element.textContent = value;
    }

    function renderRows(rows) {
        rowsBody.innerHTML = '';

        if (!rows.length) {
            const row = document.createElement('tr');
            row.className = 'empty-row';
            const cell = document.createElement('td');
            cell.colSpan = 8;
            cell.textContent = 'No Tally receipts found for this selection.';
            row.appendChild(cell);
            rowsBody.appendChild(row);
            return;
        }

        rows.forEach(item => {
            const row = document.createElement('tr');
            const cells = [
                item.receipt_date_display,
                item.party_name,
                item.voucher_type,
                item.voucher_no,
                item.reference_no,
                formatAmount(item.credit_amount || item.reference_amount),
                item.bank_name,
                (item.raw_rows || []).join(', ')
            ];

            cells.forEach((value, index) => {
                const cell = document.createElement('td');
                cell.textContent = value || '';
                if (index === 5) cell.className = 'amount-cell';
                row.appendChild(cell);
            });

            rowsBody.appendChild(row);
        });
    }

    async function loadPreview() {
        const params = new URLSearchParams();
        if (dateInput.value) params.set('date', dateInput.value);

        setStatus('Reading fcRece.xlsx...');
        metaBox.hidden = true;
        rowsBody.innerHTML = '';

        try {
            const response = await fetch(`${previewUrl}?${params.toString()}`);
            const result = await response.json();

            if (!response.ok || !result.success) {
                setStatus(result.message || 'Unable to preview Tally receipts.', true);
                renderRows([]);
                return;
            }

            setText('tallyFileName', `File: ${result.file_name}`);
            setText('tallySheetName', `Sheet: ${result.sheet_name}`);
            setText('tallyStartRow', `Data starts after Date header: row ${result.data_start_row || '-'}`);
            metaBox.hidden = false;

            renderRows(result.rows || []);
            setStatus(`${(result.rows || []).length} receipt row(s) loaded. ${result.message}`);
        } catch (error) {
            setStatus('Unable to preview Tally receipts.', true);
            renderRows([]);
        }
    }

    if (form) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();
            loadPreview();
        });
    }

    if (clearButton) {
        clearButton.addEventListener('click', function () {
            dateInput.value = '';
            loadPreview();
        });
    }
});
