import sqlite3
import csv
import os
import shutil
import json
import tempfile
import zipfile
from urllib.parse import urlencode
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, send_file, session, jsonify
import pandas as pd
import io
from openpyxl import load_workbook
from openpyxl.styles import Font
from openpyxl.utils.dataframe import dataframe_to_rows

app = Flask(__name__)
app.secret_key = "dev-secret-key"

# Add the Indian currency formatting function
def format_indian_currency(amount, decimals=True):
    if amount is None:
        return ''
    amount = float(amount)
    if not decimals:
        amount = round(amount)

    is_negative = amount < 0
    amount = abs(amount)

    integer_part = int(amount)

    s = str(integer_part)
    if len(s) <= 3:
        formatted_integer = s
    else:
        last_three = s[-3:]
        other_digits = s[:-3]
        formatted_integer_parts = []
        while other_digits:
            if len(other_digits) > 2:
                formatted_integer_parts.insert(0, other_digits[-2:])
                other_digits = other_digits[:-2]
            else:
                formatted_integer_parts.insert(0, other_digits)
                other_digits = ''
        formatted_integer = ','.join(formatted_integer_parts) + ',' + last_three

    if decimals:
        decimal_part = round((amount - integer_part) * 100)
        result = formatted_integer + f'.{decimal_part:02d}'
    else:
        result = formatted_integer

    if is_negative:
        result = '-' + result
    return result

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'database.db')
MAIN_DB_PATH = os.path.join(os.path.dirname(BASE_DIR), 'tasks.db')
CSV_PATH = os.path.join(BASE_DIR, 'data.csv')
STATIC_DIR = os.path.join(BASE_DIR, 'static')
JS_DIR = os.path.join(STATIC_DIR, 'js')
TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')
UPLOAD_DIR = os.path.join(BASE_DIR, 'uploads')
BACKUP_DIR = os.path.join(BASE_DIR, 'backups')
BACKUP_LOG_PATH = os.path.join(BACKUP_DIR, 'update_log.json')
TALLY_RECEIPT_TRIAL_PATH = os.path.join(BASE_DIR, 'fcRece.xlsx')
BACKUP_EXCLUDE_DIRS = {'backups', '__pycache__'}
BACKUP_EXCLUDE_FILES = {'server.out.log', 'server.err.log'}

DEBTOR_NAV_ACCESS_ITEMS = [
    {'key': 'import_tally_debtors', 'label': 'Import Tally Debtors', 'group': 'Import / Export'},
    {'key': 'import_tally_receipts', 'label': 'Import Tally Receipts', 'group': 'Import / Export'},
    {'key': 'download_report_excel', 'label': 'Reports in Excel Format', 'group': 'Import / Export'},
    {'key': 'client_master', 'label': 'Client Master', 'group': 'Masters'},
    {'key': 'firm_master', 'label': 'Firm Master', 'group': 'Masters'},
    {'key': 'executive_partner_master', 'label': 'Executive Partner', 'group': 'Masters'},
    {'key': 'run_followup_logic', 'label': 'Run Followup Logic', 'group': 'Masters'},
    {'key': 'clear_report', 'label': 'Clear Report', 'group': 'Masters'},
]
DEBTOR_NAV_ACCESS_KEYS = {item['key'] for item in DEBTOR_NAV_ACCESS_ITEMS}

# Register the filter
app.jinja_env.filters['indian_currency'] = format_indian_currency

@app.context_processor
def debtor_report_template_helpers():
    def debtor_url(path='/'):
        if not path.startswith('/'):
            path = '/' + path
        return f"{request.script_root}{path}"
    user_email = str(session.get('user_email', '')).lower()
    is_arif = user_email == 'arif.siddiqui@asija.in'
    debtor_nav_access = get_debtor_nav_access_for_user(user_email)
    return {
        'debtor_url': debtor_url,
        'is_arif_user': is_arif,
        'debtor_nav_access': debtor_nav_access,
        'report_as_on_label': get_report_as_on_label(),
        'report_as_on_lines': get_report_as_on_lines(),
    }

def get_app_meta(cursor, key, default=''):
    try:
        cursor.execute('SELECT value FROM app_meta WHERE key = ? LIMIT 1', (key,))
        row = cursor.fetchone()
        if row:
            return row['value'] if isinstance(row, sqlite3.Row) else row[0]
    except sqlite3.Error:
        return default
    return default

def set_app_meta(cursor, key, value):
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS app_meta (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    ''')
    cursor.execute('''
        INSERT INTO app_meta (key, value)
        VALUES (?, ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value
    ''', (key, value))

def ensure_debtor_nav_access_table(cursor):
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS debtor_nav_access (
            user_email TEXT NOT NULL,
            access_key TEXT NOT NULL,
            PRIMARY KEY (user_email, access_key)
        )
    ''')

def get_debtor_users():
    try:
        conn = sqlite3.connect(MAIN_DB_PATH)
        conn.row_factory = sqlite3.Row
        users = conn.execute('''
            SELECT u.id, u.email,
                   CASE WHEN up.user_id IS NULL THEN 0 ELSE 1 END AS has_debtor_report
            FROM users u
            LEFT JOIN user_permissions up
              ON up.user_id = u.id
             AND up.permission_key = 'daily_debtor_report'
            ORDER BY u.email COLLATE NOCASE
        ''').fetchall()
        conn.close()
        return [dict(user) for user in users]
    except sqlite3.Error:
        return []

def get_all_debtor_nav_access():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        ensure_debtor_nav_access_table(cursor)
        conn.commit()
        rows = cursor.execute('SELECT user_email, access_key FROM debtor_nav_access').fetchall()
        conn.close()
    except sqlite3.Error:
        return {}

    access = {}
    for row in rows:
        access.setdefault(str(row['user_email']).lower(), set()).add(row['access_key'])
    return access

def get_debtor_nav_access_for_user(user_email):
    user_email = str(user_email or '').lower()
    if user_email == 'arif.siddiqui@asija.in':
        return set(DEBTOR_NAV_ACCESS_KEYS)
    return get_all_debtor_nav_access().get(user_email, set())

def has_debtor_nav_access(user_email, access_key):
    return access_key in get_debtor_nav_access_for_user(user_email)

def get_debtor_access_key_for_path(path):
    path = path or '/'
    if path == '/upload' or path == '/download/billing-template':
        return 'import_tally_debtors'
    if path.startswith('/import-tally-receipts') or path.startswith('/api/import-tally-receipts'):
        return 'import_tally_receipts'
    if path == '/download/report-excel':
        return 'download_report_excel'
    if path.startswith('/client-master'):
        return 'client_master'
    if path.startswith('/firm-master'):
        return 'firm_master'
    if path.startswith('/executive-partner-master'):
        return 'executive_partner_master'
    if path == '/report/run-followup-logic':
        return 'run_followup_logic'
    if path == '/clear':
        return 'clear_report'
    return ''

def get_manual_report_update_dates():
    defaults = {
        'report_as_on_date': '',
        'last_bill_update_date': '',
        'last_receipt_update_date': '',
    }
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        defaults['report_as_on_date'] = get_app_meta(cursor, 'manual_report_as_on_date')
        defaults['last_bill_update_date'] = get_app_meta(cursor, 'manual_last_bill_update_date')
        defaults['last_receipt_update_date'] = get_app_meta(cursor, 'manual_last_receipt_update_date')
        conn.close()
    except sqlite3.Error:
        pass
    return defaults

def get_report_as_on_lines():
    manual_dates = get_manual_report_update_dates()
    manual_report_as_on = manual_dates.get('report_as_on_date')
    manual_bill_date = manual_dates.get('last_bill_update_date')
    manual_receipt_date = manual_dates.get('last_receipt_update_date')
    if manual_report_as_on or manual_bill_date or manual_receipt_date:
        return [
            f"Report as on - {format_header_date(manual_report_as_on)}",
            f"Last Bill added - {format_header_date(manual_bill_date)}",
            f"Receipt Added - {format_header_date(manual_receipt_date)}",
        ]

    label = get_report_as_on_label()
    return [label] if label else []

def get_report_as_on_label():
    manual_dates = get_manual_report_update_dates()
    manual_report_as_on = manual_dates.get('report_as_on_date')
    manual_bill_date = manual_dates.get('last_bill_update_date')
    manual_receipt_date = manual_dates.get('last_receipt_update_date')
    if manual_report_as_on or manual_bill_date or manual_receipt_date:
        return (
            f"Report Update - Report as on - {format_header_date(manual_report_as_on)}, "
            f"Last Bill added - {format_header_date(manual_bill_date)}, "
            f"Receipt Added- {format_header_date(manual_receipt_date)}"
        )

    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT MAX(bill_date) AS latest_bill_date FROM billing_report')
        latest_row = cursor.fetchone()
        latest_bill_date = latest_row['latest_bill_date'] if latest_row else ''
        cursor.execute('SELECT MAX(receipt_date) AS latest_receipt_date FROM receipt_register')
        receipt_row = cursor.fetchone()
        latest_receipt_date = receipt_row['latest_receipt_date'] if receipt_row else ''
        last_receipt_activity_at = get_app_meta(cursor, 'last_receipt_activity_at')
        last_receipt_activity_type = get_app_meta(cursor, 'last_receipt_activity_type')
        conn.close()
    except sqlite3.Error:
        return ''

    labels = []
    if latest_bill_date:
        labels.append(f"Bill Report As On (Bill Import): {format_header_date(latest_bill_date)}")

    receipt_label_date = latest_receipt_date or last_receipt_activity_at
    if receipt_label_date:
        label_type = last_receipt_activity_type or 'Import/Manual'
        labels.append(f"Receipt Last {label_type}: {format_header_date(receipt_label_date)}")

    return ' | '.join(labels)

@app.before_request
def enforce_debtor_nav_access():
    if request.endpoint == 'static':
        return None
    user_email = str(session.get('user_email', '')).lower()
    if user_email == 'arif.siddiqui@asija.in':
        return None

    access_key = get_debtor_access_key_for_path(request.path)
    if access_key and not has_debtor_nav_access(user_email, access_key):
        flash('You do not have access to this debtor report option.')
        return redirect(url_for('dashboard'))
    return None

def read_backup_log():
    try:
        with open(BACKUP_LOG_PATH, 'r', encoding='utf-8') as file:
            log = json.load(file)
            return log if isinstance(log, list) else []
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def write_backup_log(log):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    with open(BACKUP_LOG_PATH, 'w', encoding='utf-8') as file:
        json.dump(log, file, indent=2)

def add_backup_log_entry(entry):
    log = read_backup_log()
    log.insert(0, entry)
    write_backup_log(log)

def make_backup_stamp():
    base_stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    stamp = base_stamp
    counter = 1
    while os.path.exists(os.path.join(BACKUP_DIR, f'backup_{stamp}.zip')):
        stamp = f'{base_stamp}_{counter}'
        counter += 1
    return stamp

def create_project_backup(note='', backup_type='manual'):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    stamp = make_backup_stamp()
    zip_name = f'backup_{stamp}.zip'
    zip_path = os.path.join(BACKUP_DIR, zip_name)
    temp_zip_path = os.path.join(BACKUP_DIR, f'.{zip_name}.tmp')
    skipped = []
    temp_db_copy = None

    try:
        with zipfile.ZipFile(temp_zip_path, 'w', zipfile.ZIP_DEFLATED) as backup_zip:
            for current_dir, dirs, files in os.walk(BASE_DIR):
                dirs[:] = [name for name in dirs if name not in BACKUP_EXCLUDE_DIRS]
                for filename in files:
                    if filename in BACKUP_EXCLUDE_FILES or filename.startswith('~$'):
                        continue

                    file_path = os.path.join(current_dir, filename)
                    arcname = os.path.relpath(file_path, BASE_DIR)
                    try:
                        if os.path.abspath(file_path) == os.path.abspath(DB_PATH):
                            with tempfile.NamedTemporaryFile(delete=False, suffix='.db', dir=BACKUP_DIR) as temp_file:
                                temp_db_copy = temp_file.name
                            source_conn = sqlite3.connect(DB_PATH)
                            backup_conn = sqlite3.connect(temp_db_copy)
                            try:
                                source_conn.backup(backup_conn)
                            finally:
                                backup_conn.close()
                                source_conn.close()
                            backup_zip.write(temp_db_copy, arcname)
                        else:
                            backup_zip.write(file_path, arcname)
                    except Exception as exc:
                        skipped.append({'file': arcname, 'reason': str(exc)})
                    finally:
                        if temp_db_copy and os.path.exists(temp_db_copy):
                            try:
                                os.remove(temp_db_copy)
                            except OSError:
                                pass
                            temp_db_copy = None
        os.replace(temp_zip_path, zip_path)
    except Exception:
        if os.path.exists(temp_zip_path):
            try:
                os.remove(temp_zip_path)
            except OSError:
                pass
        raise

    add_backup_log_entry({
        'id': stamp,
        'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'type': backup_type,
        'note': note or 'Project backup',
        'file': zip_name,
        'skipped': skipped,
    })
    return stamp, skipped

def restore_project_backup(backup_id):
    log = read_backup_log()
    backup_entry = next((entry for entry in log if entry.get('id') == backup_id), None)
    if not backup_entry:
        return False, 'Backup not found.'

    zip_path = os.path.join(BACKUP_DIR, backup_entry.get('file', ''))
    if not os.path.exists(zip_path):
        return False, 'Backup file is missing.'

    create_project_backup(
        note=f'Automatic backup before rollback to {backup_entry.get("created_at", backup_id)}',
        backup_type='pre-rollback',
    )

    with tempfile.TemporaryDirectory(dir=BACKUP_DIR) as temp_dir:
        with zipfile.ZipFile(zip_path, 'r') as backup_zip:
            backup_zip.extractall(temp_dir)
            backup_members = {
                name.replace('/', os.sep)
                for name in backup_zip.namelist()
                if not name.endswith('/')
            }

        for current_dir, dirs, files in os.walk(BASE_DIR, topdown=False):
            relative_dir = os.path.relpath(current_dir, BASE_DIR)
            if relative_dir == '.':
                relative_dir = ''

            if relative_dir.split(os.sep)[0] in BACKUP_EXCLUDE_DIRS:
                continue

            for filename in files:
                if filename in BACKUP_EXCLUDE_FILES or filename.startswith('~$'):
                    continue

                file_path = os.path.join(current_dir, filename)
                relative_path = os.path.join(relative_dir, filename) if relative_dir else filename
                if relative_path not in backup_members:
                    try:
                        os.remove(file_path)
                    except OSError:
                        pass

            if relative_dir and relative_dir not in BACKUP_EXCLUDE_DIRS:
                try:
                    if not os.listdir(current_dir):
                        os.rmdir(current_dir)
                except OSError:
                    pass

        for current_dir, dirs, files in os.walk(temp_dir):
            for filename in files:
                source_path = os.path.join(current_dir, filename)
                relative_path = os.path.relpath(source_path, temp_dir)
                target_path = os.path.join(BASE_DIR, relative_path)
                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                shutil.copy2(source_path, target_path)

    add_backup_log_entry({
        'id': datetime.now().strftime('%Y%m%d_%H%M%S'),
        'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'type': 'rollback',
        'note': f'Rolled back to backup {backup_id}',
        'file': backup_entry.get('file', ''),
        'skipped': [],
    })
    return True, 'Rollback completed. Restart the app if code files were restored.'

def get_short_name(name):
    """Converts a name like 'Asija And Associates LLP' to 'AAA LLP'."""
    parts = name.replace('.', '').split()
    if len(parts) == 1:
        return parts[0].upper()
    short = ""
    for p in parts:
        if p.upper() in ["LLP", "LTD"]:
            short += " " + p.upper()
        else:
            short += p[0].upper()
    return short.strip()

def get_firm_short_name(cursor, firm_name):
    firm_name = (firm_name or '').strip()
    if not firm_name:
        return ''

    cursor.execute(
        'SELECT short_name FROM firm_master WHERE lower(trim(firm_name)) = lower(trim(?)) LIMIT 1',
        (firm_name,)
    )
    row = cursor.fetchone()
    if row and row[0]:
        return row[0]
    return get_short_name(firm_name)

def ensure_firm_master(cursor, firm_name):
    firm_name = (firm_name or '').strip()
    if not firm_name or firm_name == 'No Data Found':
        return

    cursor.execute(
        'SELECT id FROM firm_master WHERE lower(trim(firm_name)) = lower(trim(?)) LIMIT 1',
        (firm_name,)
    )
    if cursor.fetchone():
        return

    cursor.execute(
        'INSERT INTO firm_master (firm_name, short_name) VALUES (?, ?)',
        (firm_name, get_short_name(firm_name))
    )

def format_display_date(value):
    if not value:
        return ''

    if isinstance(value, (datetime, pd.Timestamp)):
        return value.strftime('%d-%m-%y')

    value = str(value).strip()
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y', '%Y/%m/%d', '%d-%m-%Y', '%d-%m-%y'):
        try:
            return datetime.strptime(value, fmt).strftime('%d-%m-%y')
        except ValueError:
            continue
    return value

def format_header_date(value):
    date_obj = parse_input_date(value)
    if date_obj:
        return date_obj.strftime('%d.%m.%Y')
    return format_display_date(value)

def get_current_fy_string():
    """Dynamically determines the current FY string based on today's date."""
    now = datetime.now()
    start_year = now.year if (now.month, now.day) >= (4, 2) else now.year - 1
    return f'02.04.{start_year} - 01.04.{start_year + 1}'

def parse_input_date(value):
    if not value:
        return None

    if isinstance(value, (datetime, pd.Timestamp)):
        return value.to_pydatetime() if isinstance(value, pd.Timestamp) else value

    value = str(value).strip()
    for fmt in ('%Y-%m-%d', '%Y-%m-%d %H:%M:%S', '%d-%m-%y', '%d-%m-%Y', '%d/%m/%Y', '%m/%d/%Y', '%Y/%m/%d', '%d-%b-%y', '%d-%b-%Y'):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None

def format_financial_year(value):
    bill_date = parse_input_date(value)
    if not bill_date:
        return ''

    start_year = bill_date.year if (bill_date.month, bill_date.day) >= (4, 2) else bill_date.year - 1
    return f'02.04.{start_year} - 01.04.{start_year + 1}'

def is_blank(value):
    return value is None or pd.isna(value) or str(value).strip() == ''

def first_nonblank(values):
    for value in values:
        if not is_blank(value):
            return str(value).strip()
    return ''

def normalize_tally_cell(value):
    if value is None:
        return ''
    if isinstance(value, (datetime, pd.Timestamp)):
        return value.strftime('%Y-%m-%d')
    return str(value).strip()

def parse_tally_receipt_trial(search_date='', file_path=None, file_name=None):
    """Preview-only parser for Tally receipt Excel files. It does not write to DB."""
    receipt_path = file_path or TALLY_RECEIPT_TRIAL_PATH
    receipt_name = file_name or (os.path.basename(receipt_path) if isinstance(receipt_path, (str, bytes, os.PathLike)) else 'fcRece.xlsx')
    if isinstance(receipt_path, (str, bytes, os.PathLike)) and not os.path.exists(receipt_path):
        raise FileNotFoundError('fcRece.xlsx file not found.')

    requested_date = parse_input_date(search_date) if search_date else None
    workbook = load_workbook(receipt_path, data_only=True, read_only=True)
    worksheet = None
    rows = []
    header_index = None

    for candidate in workbook.worksheets:
        candidate_rows = [tuple(row) for row in candidate.iter_rows(values_only=True)]
        candidate_header_index = None
        for index, row in enumerate(candidate_rows):
            if any(str(cell).strip().lower() == 'date' for cell in row if cell is not None):
                candidate_header_index = index
                break
        if candidate_header_index is not None:
            worksheet = candidate
            rows = candidate_rows
            header_index = candidate_header_index
            break

    if worksheet is None:
        worksheet = workbook[workbook.sheetnames[0]]

    if header_index is None:
        workbook.close()
        return {
            'file_name': receipt_name,
            'sheet_name': worksheet.title,
            'header_row': None,
            'data_start_row': None,
            'rows': [],
            'message': 'Date header not found in Tally receipt file.'
        }

    parsed_rows = []
    current_receipt = None
    data_start_index = header_index + 1

    for zero_index, row in enumerate(rows[data_start_index:], start=data_start_index):
        cells = list(row) + [None] * max(0, 10 - len(row))
        first_cell_text = normalize_tally_cell(cells[0])

        if first_cell_text.lower().startswith('total'):
            break

        row_date = parse_input_date(cells[0])
        if row_date:
            current_receipt = {
                'excel_row': zero_index + 1,
                'receipt_date': row_date.strftime('%Y-%m-%d'),
                'receipt_date_display': format_display_date(row_date),
                'party_name': normalize_tally_cell(cells[1]),
                'voucher_type': normalize_tally_cell(cells[6]),
                'voucher_no': normalize_tally_cell(cells[7]),
                'debit_amount': float(cells[8] or 0) if str(cells[8] or '').strip() else 0,
                'credit_amount': float(cells[9] or 0) if str(cells[9] or '').strip() else 0,
                'reference_type': '',
                'reference_no': '',
                'credit_days': '',
                'reference_amount': 0,
                'reference_dr_cr': '',
                'bank_name': '',
                'raw_rows': [zero_index + 1],
            }
            parsed_rows.append(current_receipt)
            continue

        if current_receipt is None:
            continue

        label = normalize_tally_cell(cells[1]).lower()
        if label == 'agst ref':
            current_receipt['reference_type'] = normalize_tally_cell(cells[1])
            current_receipt['reference_no'] = normalize_tally_cell(cells[2])
            current_receipt['credit_days'] = normalize_tally_cell(cells[3])
            current_receipt['reference_amount'] = float(cells[4] or 0) if str(cells[4] or '').strip() else 0
            current_receipt['reference_dr_cr'] = normalize_tally_cell(cells[5])
            current_receipt['raw_rows'].append(zero_index + 1)
        elif normalize_tally_cell(cells[1]):
            current_receipt['bank_name'] = normalize_tally_cell(cells[1])
            if str(cells[8] or '').strip():
                current_receipt['debit_amount'] = float(cells[8] or 0)
            current_receipt['raw_rows'].append(zero_index + 1)

    if requested_date:
        requested = requested_date.strftime('%Y-%m-%d')
        parsed_rows = [row for row in parsed_rows if row['receipt_date'] == requested]

    result = {
        'file_name': receipt_name,
        'sheet_name': worksheet.title,
        'header_row': header_index + 1,
        'data_start_row': data_start_index + 1,
        'rows': parsed_rows,
        'message': 'Preview only. No receipt data has been posted or saved.'
    }
    workbook.close()
    return result

def normalize_reference_key(value):
    return ''.join(ch for ch in str(value or '').upper() if ch.isalnum())

def get_tally_receipt_amount(row):
    reference_amount = float(row.get('reference_amount') or 0)
    credit_amount = float(row.get('credit_amount') or 0)
    debit_amount = float(row.get('debit_amount') or 0)
    if reference_amount > 0:
        return reference_amount
    if credit_amount > 0:
        return credit_amount
    return debit_amount

def ensure_receipt_register_tally_columns(cursor):
    cursor.execute('PRAGMA table_info(receipt_register)')
    existing_columns = {row[1] for row in cursor.fetchall()}
    required_columns = {
        'import_source': 'TEXT',
        'tally_voucher_no': 'TEXT',
        'tally_reference_no': 'TEXT',
        'tally_bank_name': 'TEXT',
        'tally_excel_rows': 'TEXT',
    }
    for column_name, column_type in required_columns.items():
        if column_name not in existing_columns:
            cursor.execute(f'ALTER TABLE receipt_register ADD COLUMN {column_name} {column_type}')

def build_current_bill_matches(cursor):
    matches = {}
    for row in get_report_rows(cursor):
        key = normalize_reference_key(row.get('ref_no'))
        if not key:
            continue
        matches.setdefault(key, []).append(row)
    return matches

def enrich_tally_receipt_rows(tally_rows, cursor):
    bill_matches = build_current_bill_matches(cursor)
    cursor.execute('''
        SELECT tally_voucher_no, tally_reference_no
        FROM receipt_register
        WHERE import_source = 'Tally'
          AND tally_voucher_no IS NOT NULL AND tally_reference_no IS NOT NULL
    ''')
    posted_keys = {
        (row['tally_voucher_no'] or '', normalize_reference_key(row['tally_reference_no']))
        for row in cursor.fetchall()
    }

    enriched_rows = []
    seen_preview_keys = set()
    for row in tally_rows:
        item = dict(row)
        amount = round(get_tally_receipt_amount(item), 2)
        ref_key = normalize_reference_key(item.get('reference_no'))
        voucher_no = item.get('voucher_no') or ''
        candidates = bill_matches.get(ref_key, [])
        posted_key = (voucher_no, ref_key)

        item['post_amount'] = amount
        item['matched_bill_id'] = ''
        item['matched_ref_no'] = ''
        item['matched_party_name'] = ''
        item['matched_bill_amount'] = 0
        item['post_status'] = 'Not Matched'
        item['post_message'] = 'No open bill found for reference number.'
        item['is_postable'] = False

        if posted_key in seen_preview_keys:
            item['post_status'] = 'Duplicate Preview'
            item['post_message'] = 'This voucher/reference appears more than once in the preview.'
        elif posted_key in posted_keys:
            item['post_status'] = 'Already Posted'
            item['post_message'] = 'This Tally voucher/reference is already in receipt register.'
        elif not ref_key:
            item['post_status'] = 'Missing Ref'
            item['post_message'] = 'Reference number is blank.'
        elif len(candidates) > 1:
            item['post_status'] = 'Multiple Match'
            item['post_message'] = 'More than one open bill matched this reference.'
        elif len(candidates) == 1:
            bill = candidates[0]
            bill_amount = round(float(bill.get('amount') or 0), 2)
            item['matched_bill_id'] = bill.get('id')
            item['matched_ref_no'] = bill.get('ref_no') or ''
            item['matched_party_name'] = bill.get('party_name') or ''
            item['matched_bill_amount'] = bill_amount
            if amount <= 0:
                item['post_status'] = 'Invalid Amount'
                item['post_message'] = 'Receipt amount is zero or blank.'
            elif amount > bill_amount:
                item['post_status'] = 'Excess Amount'
                item['post_message'] = 'Receipt amount is greater than current bill balance.'
            else:
                item['post_status'] = 'Ready'
                item['post_message'] = 'Ready to post.'
                item['is_postable'] = True

        if ref_key:
            seen_preview_keys.add(posted_key)
        enriched_rows.append(item)

    return enriched_rows

def post_receipt_rows(cursor, receipt_rows, receipt_mode, receipt_date, posted_at, import_meta_by_bill=None):
    import_meta_by_bill = import_meta_by_bill or {}
    current_rows = {int(row['id']): row for row in get_report_rows(cursor)}

    posted_count = 0
    posted_total = 0
    for item in receipt_rows:
        try:
            bill_id = int(item.get('row_id'))
            received_amount = float(item.get('received_amount'))
        except (TypeError, ValueError):
            raise ValueError('Please check actual received amount.')

        if received_amount <= 0:
            raise ValueError('Actual received amount must be greater than zero.')

        row = current_rows.get(bill_id)
        if not row:
            raise ValueError('One selected bill is no longer available in the debtor report.')

        bill_amount = float(row.get('amount') or 0)
        if received_amount > bill_amount:
            raise ValueError('Actual received amount cannot be greater than bill amount.')

        balance_amount = round(bill_amount - received_amount, 2)
        existing_paid_amount = float(row.get('paid_amount') or 0)
        total_paid_amount = round(existing_paid_amount + received_amount, 2)
        meta = import_meta_by_bill.get(bill_id, {})

        cursor.execute('''
            INSERT INTO receipt_register (
                source_bill_id, firm_name, short_name, bill_date, ref_no, party_name,
                bill_amount, received_amount, balance_amount, due_date, overdue_days,
                client_group, followup_partner, final_ep, crp_of_group, client_category,
                financial_year, receipt_mode, receipt_date, posted_at,
                import_source, tally_voucher_no, tally_reference_no, tally_bank_name, tally_excel_rows
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            bill_id,
            row.get('firm_name') or '',
            row.get('short_name') or '',
            row.get('bill_date') or '',
            row.get('ref_no') or '',
            row.get('party_name') or '',
            bill_amount,
            received_amount,
            balance_amount,
            row.get('due_date') or '',
            row.get('overdue_days') or 0,
            row.get('client_group') or '',
            row.get('followup_partner') or '',
            row.get('final_ep') or '',
            row.get('crp_of_group') or '',
            row.get('client_category') or '',
            row.get('financial_year') or '',
            receipt_mode,
            receipt_date,
            posted_at,
            meta.get('import_source') or '',
            meta.get('tally_voucher_no') or '',
            meta.get('tally_reference_no') or '',
            meta.get('tally_bank_name') or '',
            meta.get('tally_excel_rows') or '',
        ))

        if balance_amount <= 0:
            cursor.execute('''
                UPDATE billing_report
                SET receipt_status = ?, paid_amount = ?, closed_at = ?
                WHERE id = ?
            ''', ('full_paid', total_paid_amount, posted_at, bill_id))
        else:
            cursor.execute('''
                UPDATE billing_report
                SET amount = ?, receipt_status = ?, paid_amount = ?, closed_at = NULL
                WHERE id = ?
            ''', (balance_amount, 'part_paid', total_paid_amount, bill_id))

        current_rows[bill_id]['amount'] = balance_amount
        current_rows[bill_id]['paid_amount'] = total_paid_amount
        posted_count += 1
        posted_total += received_amount

    return posted_count, posted_total

def normalize_cell(value):
    if is_blank(value):
        return ''
    return ''.join(ch for ch in str(value).lower() if ch.isalnum())

def to_float(value):
    if is_blank(value):
        return None
    try:
        return float(str(value).replace(',', '').strip())
    except (ValueError, TypeError):
        return None

def insert_billing_row(cursor, firm_name, bill_date_obj, ref_no, party_name, amount, due_date_obj=None, overdue_days=None):
    if not firm_name or not bill_date_obj or not ref_no or not party_name or amount is None:
        return False

    ensure_firm_master(cursor, firm_name)
    due_date_obj = bill_date_obj + timedelta(days=30)
    if overdue_days is None:
        overdue_days = (datetime.now() - bill_date_obj).days

    cursor.execute('''
        INSERT INTO billing_report 
        (firm_name, short_name, bill_date, ref_no, party_name, amount, due_date, overdue_days)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        firm_name,
        get_firm_short_name(cursor, firm_name),
        bill_date_obj.strftime('%Y-%m-%d'),
        str(ref_no).strip(),
        str(party_name).strip(),
        amount,
        due_date_obj.strftime('%Y-%m-%d'),
        int(overdue_days) if overdue_days is not None else 0,
    ))
    return True

def run_followup_partner_logic(cursor):
    cursor.execute('''
        SELECT client_group, crp_of_group, COUNT(*) AS use_count
        FROM client_master
        WHERE client_group IS NOT NULL AND trim(client_group) != ''
          AND crp_of_group IS NOT NULL AND trim(crp_of_group) != ''
        GROUP BY client_group, crp_of_group
        ORDER BY client_group, use_count DESC, crp_of_group
    ''')
    crp_by_group = {}
    for row in cursor.fetchall():
        crp_by_group.setdefault(row['client_group'] if isinstance(row, sqlite3.Row) else row[0], row['crp_of_group'] if isinstance(row, sqlite3.Row) else row[1])

    cursor.execute('''
        SELECT
            billing_report.id,
            billing_report.party_name,
            billing_report.amount,
            COALESCE(NULLIF(billing_report.group_override, ''), client_master.client_group) AS client_group,
            client_master.crp_of_group,
            COALESCE(NULLIF(billing_report.ep_override, ''), (
                SELECT executive_partner_master.final_ep
                FROM executive_partner_master
                WHERE executive_partner_master.partner_name != ''
                  AND lower(billing_report.ref_no) LIKE '%' || lower(executive_partner_master.partner_name) || '%'
                ORDER BY length(executive_partner_master.partner_name) DESC
                LIMIT 1
            )) AS final_ep
        FROM billing_report
        LEFT JOIN client_master
            ON lower(trim(billing_report.party_name)) = lower(trim(client_master.client_name))
        WHERE COALESCE(billing_report.receipt_status, 'open') != 'full_paid'
    ''')
    columns = [description[0] for description in cursor.description]
    rows = [
        dict(row) if isinstance(row, sqlite3.Row) else dict(zip(columns, row))
        for row in cursor.fetchall()
    ]

    for row in rows:
        group_name = (row.get('client_group') or '').strip()
        if group_name and crp_by_group.get(group_name):
            row['crp_of_group'] = crp_by_group[group_name]

    group_data = {}
    for row in rows:
        group_name = (row.get('client_group') or row.get('party_name') or '').strip()
        ep_name = (row.get('final_ep') or '').strip()
        crp_name = (row.get('crp_of_group') or '').strip()
        amount = row.get('amount') or 0

        if not group_name:
            continue

        if group_name not in group_data:
            group_data[group_name] = {
                'crp': crp_name,
                'ep_totals': {},
            }
        elif not group_data[group_name]['crp'] and crp_name:
            group_data[group_name]['crp'] = crp_name

        if ep_name:
            group_data[group_name]['ep_totals'][ep_name] = (
                group_data[group_name]['ep_totals'].get(ep_name, 0) + amount
            )

    followup_by_group = {}
    for group_name, data in group_data.items():
        crp_name = data['crp']
        ep_totals = data['ep_totals']
        ep_names = set(ep_totals)
        non_crp_ep_totals = {
            ep_name: total
            for ep_name, total in ep_totals.items()
            if ep_name != crp_name
        }

        if not ep_names:
            followup_by_group[group_name] = crp_name
        elif crp_name and crp_name in ep_names:
            followup_by_group[group_name] = crp_name
        elif len(non_crp_ep_totals) == 1:
            followup_by_group[group_name] = next(iter(non_crp_ep_totals))
        elif non_crp_ep_totals:
            followup_by_group[group_name] = max(non_crp_ep_totals, key=non_crp_ep_totals.get)
        else:
            followup_by_group[group_name] = crp_name

    updated_count = 0
    for row in rows:
        group_name = (row.get('client_group') or row.get('party_name') or '').strip()
        followup_partner = followup_by_group.get(group_name, '')
        cursor.execute(
            'UPDATE billing_report SET followup_partner = ? WHERE id = ?',
            (followup_partner, row.get('id'))
        )
        updated_count += cursor.rowcount

    set_app_meta(cursor, 'last_followup_logic_run_at', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    return updated_count

def find_report_header(df):
    for row_index in range(min(len(df), 30)):
        labels = [normalize_cell(value) for value in df.iloc[row_index].tolist()]
        next_labels = [normalize_cell(value) for value in df.iloc[row_index + 1].tolist()] if row_index + 1 < len(df) else []
        combined = [
            f'{labels[index]}{next_labels[index] if index < len(next_labels) else ""}'
            for index in range(len(labels))
        ]

        date_idx = next((index for index, label in enumerate(combined) if label == 'date'), None)
        ref_idx = next((index for index, label in enumerate(combined) if label in ('refno', 'refnumber', 'referenceno')), None)
        party_idx = next((index for index, label in enumerate(combined) if 'party' in label and 'name' in label), None)
        amount_idx = next((index for index, label in enumerate(combined) if label in ('amount', 'pendingamount') or ('pending' in label and 'amount' in label)), None)
        due_idx = next((index for index, label in enumerate(combined) if label in ('dueon', 'duedate')), None)
        overdue_idx = next((index for index, label in enumerate(combined) if 'overdue' in label), None)

        if date_idx is not None and ref_idx is not None and party_idx is not None and amount_idx is not None:
            return {
                'row_index': row_index,
                'date_idx': date_idx,
                'ref_idx': ref_idx,
                'party_idx': party_idx,
                'amount_idx': amount_idx,
                'due_idx': due_idx,
                'overdue_idx': overdue_idx,
            }
    return None

def process_data_file(data_file, manual_firm_name=''):
    """Parses a file and appends rows to the database."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        imported_count = 0
        firm_name = manual_firm_name.strip() or "No Data Found"
        if data_file.endswith('.csv'):
            with open(data_file, 'r', encoding='utf-8', errors='ignore') as f:
                reader = list(csv.reader(f))
                if not reader: return
                firm_name = manual_firm_name.strip() or first_nonblank(reader[0]) or firm_name
                rows_data = reader[1:]
                for row in rows_data:
                    try:
                        if len(row) < 4:
                            continue
                        bill_date_obj = parse_input_date(row[0])
                        amount = to_float(row[3])
                        if insert_billing_row(cursor, firm_name, bill_date_obj, row[1], row[2], amount):
                            imported_count += 1
                    except Exception:
                        continue
        else:
            with pd.ExcelFile(data_file) as xls:
                df_firm = pd.read_excel(xls, header=None, nrows=1)
                if not df_firm.empty:
                    firm_name = manual_firm_name.strip() or first_nonblank(df_firm.iloc[0].tolist()) or firm_name

                df = pd.read_excel(xls, header=None)
                header = find_report_header(df)
                if header:
                    start_index = header['row_index'] + 1
                    for row_index in range(start_index, len(df)):
                        row = df.iloc[row_index]
                        try:
                            bill_date_obj = parse_input_date(row.iloc[header['date_idx']])
                            ref_no = row.iloc[header['ref_idx']]
                            party_name = row.iloc[header['party_idx']]
                            amount = to_float(row.iloc[header['amount_idx']])
                            due_date_obj = parse_input_date(row.iloc[header['due_idx']]) if header['due_idx'] is not None else None
                            overdue_days = to_float(row.iloc[header['overdue_idx']]) if header['overdue_idx'] is not None else None
                            if insert_billing_row(cursor, firm_name, bill_date_obj, ref_no, party_name, amount, due_date_obj, overdue_days):
                                imported_count += 1
                        except Exception:
                            continue
                else:
                    df_main = pd.read_excel(xls, skiprows=1, header=None)
                    for row in df_main.values.tolist():
                        try:
                            if len(row) < 4:
                                continue
                            bill_date_obj = parse_input_date(row[0])
                            amount = to_float(row[3])
                            if insert_billing_row(cursor, firm_name, bill_date_obj, row[1], row[2], amount):
                                imported_count += 1
                        except Exception:
                            continue
        if imported_count > 0:
            set_app_meta(cursor, 'last_debtor_imported_at', datetime.now().strftime('%Y-%m-%d'))
            run_followup_partner_logic(cursor)
        conn.commit()
        return imported_count
    except Exception as e:
        print(f"Error processing file: {e}")
        return 0
    finally:
        conn.close()

def init_db():
    """Initializes the database environment and handles discovery load."""
    os.makedirs(STATIC_DIR, exist_ok=True)
    os.makedirs(JS_DIR, exist_ok=True)
    os.makedirs(TEMPLATE_DIR, exist_ok=True)
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    os.makedirs(BACKUP_DIR, exist_ok=True)

    # Move static files if in root
    for src, dst_dir in [(os.path.join(BASE_DIR, 'style.css'), STATIC_DIR), 
                          (os.path.join(BASE_DIR, 'main.js'), JS_DIR)]:
        if os.path.exists(src) and not os.path.exists(os.path.join(dst_dir, os.path.basename(src))):
            shutil.move(src, os.path.join(dst_dir, os.path.basename(src)))

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS billing_report (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            firm_name TEXT,
            short_name TEXT,
            bill_date TEXT,
            ref_no TEXT,
            party_name TEXT,
            amount REAL,
            due_date TEXT,
            overdue_days INTEGER
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS client_master (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_name TEXT NOT NULL,
            phone TEXT,
            email TEXT,
            gstin TEXT,
            client_group TEXT,
            crp_of_group TEXT,
            reffered_by TEXT,
            whatapp_group TEXT,
            client_category TEXT
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS executive_partner_master (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            partner_name TEXT NOT NULL UNIQUE,
            final_ep TEXT
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS firm_master (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            firm_name TEXT NOT NULL UNIQUE COLLATE NOCASE,
            short_name TEXT
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS receipt_register (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_bill_id INTEGER,
            firm_name TEXT,
            short_name TEXT,
            bill_date TEXT,
            ref_no TEXT,
            party_name TEXT,
            bill_amount REAL,
            received_amount REAL,
            balance_amount REAL,
            due_date TEXT,
            overdue_days INTEGER,
            client_group TEXT,
            followup_partner TEXT,
            final_ep TEXT,
            crp_of_group TEXT,
            client_category TEXT,
            financial_year TEXT,
            receipt_mode TEXT,
            receipt_date TEXT,
            posted_at TEXT
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS app_meta (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    ''')
    ensure_debtor_nav_access_table(cursor)

    ensure_receipt_register_tally_columns(cursor)

    cursor.execute('PRAGMA table_info(client_master)')
    existing_client_columns = {row[1] for row in cursor.fetchall()}
    required_client_columns = {
        'client_group': 'TEXT',
        'crp_of_group': 'TEXT',
        'reffered_by': 'TEXT',
        'whatapp_group': 'TEXT',
        'client_category': 'TEXT',
    }
    for column_name, column_type in required_client_columns.items():
        if column_name not in existing_client_columns:
            cursor.execute(f'ALTER TABLE client_master ADD COLUMN {column_name} {column_type}')

    cursor.execute('PRAGMA table_info(billing_report)')
    existing_billing_columns = {row[1] for row in cursor.fetchall()}
    if 'ep_override' not in existing_billing_columns:
        cursor.execute('ALTER TABLE billing_report ADD COLUMN ep_override TEXT')
    if 'receipt_status' not in existing_billing_columns:
        cursor.execute("ALTER TABLE billing_report ADD COLUMN receipt_status TEXT DEFAULT 'open'")
    if 'paid_amount' not in existing_billing_columns:
        cursor.execute('ALTER TABLE billing_report ADD COLUMN paid_amount REAL DEFAULT 0')
    if 'closed_at' not in existing_billing_columns:
        cursor.execute('ALTER TABLE billing_report ADD COLUMN closed_at TEXT')
    if 'group_override' not in existing_billing_columns:
        cursor.execute('ALTER TABLE billing_report ADD COLUMN group_override TEXT')
    if 'followup_partner' not in existing_billing_columns:
        cursor.execute('ALTER TABLE billing_report ADD COLUMN followup_partner TEXT')

    cursor.execute('PRAGMA table_info(executive_partner_master)')
    existing_partner_columns = {row[1] for row in cursor.fetchall()}
    if 'final_ep' not in existing_partner_columns:
        cursor.execute('ALTER TABLE executive_partner_master ADD COLUMN final_ep TEXT')

    cursor.execute('''
        INSERT OR IGNORE INTO firm_master (firm_name, short_name)
        SELECT DISTINCT firm_name, short_name
        FROM billing_report
        WHERE firm_name IS NOT NULL AND trim(firm_name) != ''
    ''')
    cursor.execute('''
        UPDATE billing_report
        SET due_date = date(bill_date, '+30 days')
        WHERE bill_date IS NOT NULL AND trim(bill_date) != ''
    ''')
    cursor.execute('''
        SELECT COUNT(*)
        FROM billing_report
        WHERE COALESCE(followup_partner, '') = ''
          AND COALESCE(receipt_status, 'open') != 'full_paid'
    ''')
    if cursor.fetchone()[0] > 0:
        run_followup_partner_logic(cursor)
    conn.commit()
    
    # Load data only if the table is empty to prevent duplicates on restart
    cursor.execute('SELECT COUNT(*) FROM billing_report')
    is_empty = cursor.fetchone()[0] == 0
    conn.close()

    if is_empty:
        data_file = None
        for name in ['data', 'input']:
            for ext in ['.csv', '.xlsx']:
                p = os.path.join(BASE_DIR, f'{name}{ext}')
                if os.path.exists(p):
                    data_file = p
                    break
            if data_file: break
        if data_file:
            process_data_file(data_file)

def get_report_rows(cursor):
    cursor.execute('''
        SELECT client_group, crp_of_group, COUNT(*) AS use_count
        FROM client_master
        WHERE client_group IS NOT NULL AND trim(client_group) != ''
          AND crp_of_group IS NOT NULL AND trim(crp_of_group) != ''
        GROUP BY client_group, crp_of_group
        ORDER BY client_group, use_count DESC, crp_of_group
    ''')
    crp_by_group = {}
    for row in cursor.fetchall():
        crp_by_group.setdefault(row['client_group'], row['crp_of_group'])

    cursor.execute('''
        SELECT
            billing_report.*,
            COALESCE(NULLIF(billing_report.group_override, ''), client_master.client_group) AS client_group,
            client_master.client_category,
            client_master.crp_of_group,
            COALESCE(NULLIF(billing_report.ep_override, ''), (
                SELECT executive_partner_master.final_ep
                FROM executive_partner_master
                WHERE executive_partner_master.partner_name != ''
                  AND lower(billing_report.ref_no) LIKE '%' || lower(executive_partner_master.partner_name) || '%'
                ORDER BY length(executive_partner_master.partner_name) DESC
                LIMIT 1
            )) AS final_ep
        FROM billing_report
        LEFT JOIN client_master
            ON lower(trim(billing_report.party_name)) = lower(trim(client_master.client_name))
        WHERE COALESCE(billing_report.receipt_status, 'open') != 'full_paid'
    ''')
    rows = [dict(row) for row in cursor.fetchall()]
    for row in rows:
        group_name = (row.get('client_group') or '').strip()
        if group_name and crp_by_group.get(group_name):
            row['crp_of_group'] = crp_by_group[group_name]

    for row in rows:
        row['followup_partner'] = row.get('followup_partner') or ''
        row['bill_date_display'] = format_display_date(row.get('bill_date'))
        bill_date_obj = parse_input_date(row.get('bill_date'))
        if bill_date_obj:
            due_date_obj = bill_date_obj + timedelta(days=30)
            row['due_date'] = due_date_obj.strftime('%Y-%m-%d')
            row['due_date_display'] = format_display_date(row['due_date'])
        else:
            row['due_date_display'] = format_display_date(row.get('due_date'))
        row['financial_year'] = format_financial_year(row.get('bill_date'))

    rows.sort(key=lambda row: (
        (row.get('client_group') or row.get('party_name') or '').lower(),
        (row.get('party_name') or '').lower(),
        row.get('bill_date') or '',
        row.get('ref_no') or '',
    ))
    return rows

def build_report_page_context(active_page='report', page_title='Firm Billing Report'):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    rows = get_report_rows(cursor)

    cursor.execute('''
        SELECT source_bill_id, receipt_date, bill_amount, received_amount, balance_amount, receipt_mode
        FROM receipt_register
        WHERE source_bill_id IS NOT NULL
        ORDER BY receipt_date, id
    ''')
    receipts_by_bill = {}
    for receipt in cursor.fetchall():
        receipts_by_bill.setdefault(receipt['source_bill_id'], []).append(receipt)

    for row in rows:
        receipts = receipts_by_bill.get(row.get('id'), [])
        if not receipts:
            continue

        receipt_lines = []
        for receipt in receipts:
            received_amount = float(receipt['received_amount'] or 0)
            bill_amount = float(receipt['bill_amount'] or 0) if 'bill_amount' in receipt.keys() else 0
            balance_amount = float(receipt['balance_amount'] or 0) if 'balance_amount' in receipt.keys() else 0
            receipt_lines.append(
                f"{format_display_date(receipt['receipt_date'])} | Original Bill: Rs {format_indian_currency(bill_amount)} | Receipt: Rs {format_indian_currency(received_amount)} | Balance: Rs {format_indian_currency(balance_amount)} | {receipt['receipt_mode'] or 'Receipt'}"
            )
        total_received = sum(float(receipt['received_amount'] or 0) for receipt in receipts)
        latest_receipt = receipts[-1]
        original_bill_amount = float(latest_receipt['bill_amount'] or 0)
        balance_amount = float(latest_receipt['balance_amount'] or 0)
        row['part_payment_summary'] = (
            f"Original Rs {format_indian_currency(original_bill_amount)} | "
            f"Paid Rs {format_indian_currency(total_received)} | "
            f"Balance Rs {format_indian_currency(balance_amount)}"
        )
        row['receipt_hover_note'] = (
            "Part payment received\n"
            + "\n".join(receipt_lines)
            + f"\nTotal received: Rs {format_indian_currency(total_received)}"
        )
    
    # Calculate firm-wise summary
    cursor.execute('''
        SELECT short_name, COUNT(*) as bill_count, SUM(amount) as total_amount 
        FROM billing_report GROUP BY short_name
    ''')
    summary = cursor.fetchall()

    cursor.execute('''
        SELECT DISTINCT COALESCE(NULLIF(final_ep, ''), partner_name) AS ep_name
        FROM executive_partner_master
        WHERE COALESCE(NULLIF(final_ep, ''), partner_name) != ''
        ORDER BY ep_name
    ''')
    ep_options = [row['ep_name'] for row in cursor.fetchall()]

    cursor.execute('''
        SELECT DISTINCT client_group
        FROM client_master
        WHERE client_group IS NOT NULL AND trim(client_group) != ''
        ORDER BY client_group
    ''')
    group_options = [row['client_group'] for row in cursor.fetchall()]

    cursor.execute('''
        SELECT client_group, crp_of_group, COUNT(*) AS use_count
        FROM client_master
        WHERE client_group IS NOT NULL AND trim(client_group) != ''
          AND crp_of_group IS NOT NULL AND trim(crp_of_group) != ''
        GROUP BY client_group, crp_of_group
        ORDER BY client_group, use_count DESC, crp_of_group
    ''')
    group_crp_map = {}
    for row in cursor.fetchall():
        group_crp_map.setdefault(row['client_group'], row['crp_of_group'])

    cursor.execute('''
        SELECT client_name, client_group
        FROM client_master
        WHERE client_name IS NOT NULL AND trim(client_name) != ''
        ORDER BY client_name
    ''')
    master_clients = [
        {
            'client_name': row['client_name'],
            'client_group': row['client_group'] or '',
        }
        for row in cursor.fetchall()
    ]
    master_client_names = [client['client_name'] for client in master_clients]

    cursor.execute('SELECT firm_name, short_name FROM firm_master ORDER BY firm_name')
    firm_options = cursor.fetchall()
    
    firm_name = rows[0]['firm_name'] if rows else "No Data"
    conn.close()
    return {
        'rows': rows,
        'firm_name': firm_name,
        'summary': summary,
        'ep_options': ep_options,
        'group_options': group_options,
        'group_crp_map': group_crp_map,
        'master_client_names': master_client_names,
        'master_clients': master_clients,
        'firm_options': firm_options,
        'active_page': active_page,
        'page_title': page_title,
    }

@app.route('/')
def index():
    return dashboard()

@app.route('/report')
def report():
    return render_template(
        'index.html',
        **build_report_page_context()
    )

def build_dashboard_context():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    rows = get_report_rows(cursor)
    cursor.execute('SELECT firm_name, short_name FROM firm_master ORDER BY firm_name')
    firm_options = cursor.fetchall()
    conn.close()

    total_amount = sum(float(row.get('amount') or 0) for row in rows)
    total_bills = len(rows)
    avg_bill = total_amount / total_bills if total_bills else 0
    today = datetime.now()

    def add_amount(summary, key, amount):
        label = (key or 'Unassigned').strip() or 'Unassigned'
        item = summary.setdefault(label, {'label': label, 'count': 0, 'total': 0})
        item['count'] += 1
        item['total'] += amount

    firm_summary = {}
    followup_summary = {}
    ep_summary = {}
    category_summary = {}
    fy_summary = {}
    ageing_summary = {
        '0-30 Days': {'label': '0-30 Days', 'count': 0, 'total': 0},
        '31-90 Days': {'label': '31-90 Days', 'count': 0, 'total': 0},
        '91-180 Days': {'label': '91-180 Days', 'count': 0, 'total': 0},
        '180+ Days': {'label': '180+ Days', 'count': 0, 'total': 0},
    }

    overdue_total = 0
    overdue_count = 0
    for row in rows:
        amount = float(row.get('amount') or 0)
        add_amount(firm_summary, row.get('short_name') or row.get('firm_name'), amount)
        add_amount(followup_summary, row.get('followup_partner'), amount)
        add_amount(ep_summary, row.get('final_ep'), amount)
        add_amount(category_summary, row.get('client_category'), amount)
        add_amount(fy_summary, row.get('financial_year') or 'Unknown', amount)

        bucket = due_ageing_bucket(row)
        ageing_summary[bucket]['count'] += 1
        ageing_summary[bucket]['total'] += amount

        try:
            overdue_days = int(float(row.get('overdue_days') or 0))
        except (TypeError, ValueError):
            overdue_days = 0
        if overdue_days > 30:
            overdue_total += amount
            overdue_count += 1

    def sorted_items(summary, limit=None):
        items = sorted(summary.values(), key=lambda item: item['total'], reverse=True)
        return items[:limit] if limit else items

    high_risk_rows = sorted(rows, key=lambda row: float(row.get('amount') or 0), reverse=True)[:8]

    detail_base_url = f"{request.script_root}/sub-report/detail"
    ageing_items = list(ageing_summary.values())
    for item in ageing_items:
        item['url'] = f"{detail_base_url}?{urlencode({'ageing': item['label']})}"

    chart_data = {
        'firm': sorted_items(firm_summary, 8),
        'followup': sorted_items(followup_summary, 8),
        'ep': sorted_items(ep_summary, 8),
        'category': sorted_items(category_summary, 8),
        'fy': sorted_items(fy_summary),
        'ageing': ageing_items,
    }

    return {
        'active_page': 'dashboard',
        'firm_options': firm_options,
        'total_amount': total_amount,
        'total_bills': total_bills,
        'avg_bill': avg_bill,
        'overdue_total': overdue_total,
        'overdue_count': overdue_count,
        'chart_data': chart_data,
        'top_followups': sorted_items(followup_summary, 6),
        'top_categories': sorted_items(category_summary, 6),
        'high_risk_rows': high_risk_rows,
        'page_title': 'Debtor Dashboard',
    }

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html', **build_dashboard_context())

@app.route('/receipts')
def receipts():
    return render_template(
        'index.html',
        **build_report_page_context(active_page='receipts', page_title='Receipts')
    )

@app.route('/receipt-register')
def receipt_register():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('''
        SELECT *
        FROM receipt_register
        ORDER BY receipt_date DESC, id DESC
    ''')
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()

    for row in rows:
        row['bill_date_display'] = format_display_date(row.get('bill_date'))
        row['due_date_display'] = format_display_date(row.get('due_date'))
        row['receipt_date_display'] = format_display_date(row.get('receipt_date'))

    return render_template('receipt_register.html', rows=rows, active_page='receipt_register')

@app.route('/receipt-register/weekly-report')
def receipt_register_weekly_report():
    start_date_obj = parse_input_date(request.args.get('start_date', '').strip())
    end_date_obj = parse_input_date(request.args.get('end_date', '').strip())

    if not start_date_obj or not end_date_obj:
        flash('Please select both From Date and To Date for weekly report.')
        return redirect(url_for('receipt_register'))

    start_date = start_date_obj.strftime('%Y-%m-%d')
    end_date = end_date_obj.strftime('%Y-%m-%d')
    if start_date > end_date:
        start_date, end_date = end_date, start_date

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('''
        SELECT *
        FROM receipt_register
        WHERE receipt_date BETWEEN ? AND ?
        ORDER BY followup_partner, receipt_date, id
    ''', (start_date, end_date))
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()

    for row in rows:
        row['receipt_date_display'] = format_header_date(row.get('receipt_date'))
        row['bill_date_display'] = format_header_date(row.get('bill_date'))
        row['due_date_display'] = format_header_date(row.get('due_date'))

    detail_rows = []
    summary = {}
    for row in rows:
        followup_partner = row.get('followup_partner') or 'Unassigned'
        received_amount = float(row.get('received_amount') or 0)
        balance_amount = float(row.get('balance_amount') or 0)
        item = summary.setdefault(followup_partner, {
            'Followup Partner': followup_partner,
            'Receipt Count': 0,
            'Received Amount': 0,
            'Balance Amount': 0,
        })
        item['Receipt Count'] += 1
        item['Received Amount'] += received_amount
        item['Balance Amount'] += balance_amount

        detail_rows.append({
            'Receipt Date': row.get('receipt_date_display') or '',
            'Mode': row.get('receipt_mode') or '',
            'Source': row.get('import_source') or 'Manual',
            'Tally Vch': row.get('tally_voucher_no') or '',
            'Firm': row.get('short_name') or '',
            'Bill Date': row.get('bill_date_display') or '',
            'Bill No': row.get('ref_no') or '',
            'Entity': row.get('party_name') or '',
            'Bill Amount': row.get('bill_amount') or 0,
            'Received Amount': received_amount,
            'Balance': balance_amount,
            'Due Date': row.get('due_date_display') or '',
            'Over Due': row.get('overdue_days') or 0,
            'Group': row.get('client_group') or '',
            'Followup Partner': followup_partner,
            'EP': row.get('final_ep') or '',
            'CRP': row.get('crp_of_group') or '',
            'Category': row.get('client_category') or '',
            'F.Y.': row.get('financial_year') or '',
            'Posted At': row.get('posted_at') or '',
        })

    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        pd.DataFrame(sorted(summary.values(), key=lambda item: item['Followup Partner'])).to_excel(
            writer,
            index=False,
            sheet_name='Followup Summary',
        )
        pd.DataFrame(detail_rows).to_excel(writer, index=False, sheet_name='Receipt Details')
        for sheet in writer.book.worksheets:
            sheet.freeze_panes = 'A2'
            for column_cells in sheet.columns:
                max_length = 0
                for cell in column_cells:
                    if cell.value is not None:
                        max_length = max(max_length, len(str(cell.value)))
                sheet.column_dimensions[column_cells[0].column_letter].width = min(max_length + 2, 42)

    output.seek(0)
    filename = f"weekly_receipt_report_{start_date}_to_{end_date}.xlsx"
    return send_file(
        output,
        download_name=filename,
        as_attachment=True,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

def format_message_date(value):
    date_obj = parse_input_date(value)
    if date_obj:
        return date_obj.strftime('%d/%m/%Y')
    return value or ''

def build_weekly_recovery_context(start_date_obj, end_date_obj):
    start_date = start_date_obj.strftime('%Y-%m-%d')
    end_date = end_date_obj.strftime('%Y-%m-%d')
    if start_date > end_date:
        start_date, end_date = end_date, start_date

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('''
        SELECT *
        FROM receipt_register
        WHERE receipt_date BETWEEN ? AND ?
        ORDER BY followup_partner, receipt_date, id
    ''', (start_date, end_date))
    rows = [dict(row) for row in cursor.fetchall()]

    cursor.execute('''
        SELECT MIN(receipt_date) AS first_receipt_date
        FROM receipt_register
        WHERE receipt_date <= ?
    ''', (end_date,))
    first_row = cursor.fetchone()
    cumulative_start = (first_row['first_receipt_date'] if first_row else '') or start_date

    cursor.execute('''
        SELECT COALESCE(SUM(received_amount), 0) AS cumulative_total
        FROM receipt_register
        WHERE receipt_date BETWEEN ? AND ?
    ''', (cumulative_start, end_date))
    cumulative_total = float(cursor.fetchone()['cumulative_total'] or 0)
    conn.close()

    partner_summary = {}
    weekly_total = 0
    for row in rows:
        partner = row.get('followup_partner') or 'Unassigned'
        received_amount = float(row.get('received_amount') or 0)
        weekly_total += received_amount
        item = partner_summary.setdefault(partner, {
            'partner': partner,
            'receipt_count': 0,
            'received_amount': 0,
        })
        item['receipt_count'] += 1
        item['received_amount'] += received_amount

    summary_rows = sorted(
        partner_summary.values(),
        key=lambda item: item['received_amount'],
        reverse=True
    )
    top_partners = summary_rows[:3]

    if top_partners:
        if len(top_partners) == 1:
            top_line = (
                f"{top_partners[0]['partner']} has done a good job by recovering "
                f"Rs {format_indian_currency(top_partners[0]['received_amount'], decimals=False)}."
            )
        else:
            partner_parts = [
                f"{item['partner']} (Rs {format_indian_currency(item['received_amount'], decimals=False)})"
                for item in top_partners
            ]
            top_line = f"{', '.join(partner_parts[:-1])} and {partner_parts[-1]} have done a good job."
    else:
        top_line = "No recovery has been posted for the selected period."

    message = (
        "A Very Good Afternoon to Everyone,\n\n"
        f"I am hereby sharing the client recovery for the Week from {format_message_date(start_date)} to {format_message_date(end_date)}.\n\n"
        f"With our combined efforts, we have been able to recover a sum of Rs {format_indian_currency(weekly_total, decimals=False)} /- during this period.\n\n"
        f"{top_line}\n\n"
        "I am sure others have also worked hard and tried to recover as much as possible.\n\n"
        f"During this period from {format_message_date(cumulative_start)} to {format_message_date(end_date)} "
        f"we have recovered total Rs {format_indian_currency(cumulative_total, decimals=False)} /-"
    )

    for row in summary_rows:
        row['received_amount_display'] = format_indian_currency(row['received_amount'], decimals=False)

    return {
        'active_page': 'weekly_recovery_report',
        'start_date': start_date,
        'end_date': end_date,
        'start_date_display': format_message_date(start_date),
        'end_date_display': format_message_date(end_date),
        'weekly_total': weekly_total,
        'weekly_total_display': format_indian_currency(weekly_total, decimals=False),
        'cumulative_start_display': format_message_date(cumulative_start),
        'cumulative_total_display': format_indian_currency(cumulative_total, decimals=False),
        'summary_rows': summary_rows,
        'receipt_rows': rows,
        'message': message,
        'page_title': 'Weekly Recovery Report',
    }

@app.route('/weekly-recovery-report')
def weekly_recovery_report():
    start_date_obj = parse_input_date(request.args.get('start_date', '').strip())
    end_date_obj = parse_input_date(request.args.get('end_date', '').strip())

    if not start_date_obj or not end_date_obj:
        flash('Please select both From Date and To Date for Weekly Recovery Report.')
        return redirect(url_for('receipt_register'))

    return render_template(
        'weekly_recovery_report.html',
        **build_weekly_recovery_context(start_date_obj, end_date_obj)
    )

@app.route('/import-tally-receipts')
def import_tally_receipts():
    return render_template('tally_receipts_import.html', active_page='import_tally_receipts')

@app.route('/import-tally-receipts/upload', methods=['POST'])
def import_tally_receipts_upload():
    if 'file' not in request.files:
        flash('No receipt file selected.', 'error')
        return redirect(url_for('import_tally_receipts'))

    file = request.files['file']
    if file.filename == '':
        flash('No receipt file selected.', 'error')
        return redirect(url_for('import_tally_receipts'))

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in {'.xlsx', '.xlsm'}:
        flash('Invalid receipt file. Please upload fcRece.xlsx or another .xlsx receipt export.', 'error')
        return redirect(url_for('import_tally_receipts'))

    try:
        file_bytes = file.read()
        preview = parse_tally_receipt_trial('', file_path=io.BytesIO(file_bytes), file_name=file.filename)
        if not preview.get('data_start_row') or not preview.get('rows'):
            flash('Receipt file was not imported because Date header/receipt rows were not found. Old fcRece.xlsx is unchanged.', 'error')
            return redirect(url_for('import_tally_receipts'))

        with open(TALLY_RECEIPT_TRIAL_PATH, 'wb') as target_file:
            target_file.write(file_bytes)

        try:
            os.makedirs(UPLOAD_DIR, exist_ok=True)
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            archive_path = os.path.join(UPLOAD_DIR, f'tally_receipts_{timestamp}{ext}')
            with open(archive_path, 'wb') as archive_file:
                archive_file.write(file_bytes)
        except OSError:
            pass
    except OSError as exc:
        flash(f'Unable to save receipt file: {exc}', 'error')
        return redirect(url_for('import_tally_receipts'))
    except Exception as exc:
        flash(f'Receipt file was not imported: {exc}. Old fcRece.xlsx is unchanged.', 'error')
        return redirect(url_for('import_tally_receipts'))

    flash(f'Receipt file imported as {os.path.basename(TALLY_RECEIPT_TRIAL_PATH)}.', 'success')
    return redirect(url_for('import_tally_receipts', uploaded='1'))

@app.route('/api/import-tally-receipts/preview')
def import_tally_receipts_preview():
    search_date = request.args.get('date', '').strip()
    try:
        preview = parse_tally_receipt_trial(search_date)
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        ensure_receipt_register_tally_columns(cursor)
        preview['rows'] = enrich_tally_receipt_rows(preview.get('rows') or [], cursor)
        conn.commit()
        conn.close()
        return jsonify({'success': True, **preview})
    except Exception as exc:
        return jsonify({'success': False, 'message': f'Unable to preview Tally receipts: {exc}'}), 500

@app.route('/api/import-tally-receipts/post', methods=['POST'])
def import_tally_receipts_post():
    payload = request.get_json(silent=True) or {}
    search_date = (payload.get('date') or '').strip()

    try:
        preview = parse_tally_receipt_trial(search_date)
    except Exception as exc:
        return jsonify({'success': False, 'message': f'Unable to read Tally receipts: {exc}'}), 500

    receipt_date_obj = parse_input_date(search_date or '')
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    try:
        ensure_receipt_register_tally_columns(cursor)
        enriched_rows = enrich_tally_receipt_rows(preview.get('rows') or [], cursor)
        postable_rows = [row for row in enriched_rows if row.get('is_postable')]

        if not postable_rows:
            raise ValueError('No ready Tally receipts found to post.')

        receipt_rows_by_date = {}
        import_meta_by_date = {}
        for row in postable_rows:
            bill_id = int(row.get('matched_bill_id'))
            row_receipt_date = parse_input_date(row.get('receipt_date') or '')
            if receipt_date_obj and row_receipt_date and row_receipt_date.strftime('%Y-%m-%d') != receipt_date_obj.strftime('%Y-%m-%d'):
                continue
            receipt_date = (row_receipt_date or receipt_date_obj or datetime.now()).strftime('%Y-%m-%d')

            receipt_rows_by_date.setdefault(receipt_date, []).append({
                'row_id': bill_id,
                'received_amount': row.get('post_amount'),
            })
            import_meta_by_date.setdefault(receipt_date, {})[bill_id] = {
                'import_source': 'Tally',
                'tally_voucher_no': row.get('voucher_no') or '',
                'tally_reference_no': row.get('reference_no') or '',
                'tally_bank_name': row.get('bank_name') or '',
                'tally_excel_rows': ', '.join(str(value) for value in (row.get('raw_rows') or [])),
            }

        if not receipt_rows_by_date:
            raise ValueError('No receipts matched the selected date.')

        posted_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        posted_count = 0
        posted_total = 0
        for receipt_date, receipt_rows in receipt_rows_by_date.items():
            group_count, group_total = post_receipt_rows(
                cursor,
                receipt_rows,
                'Bank',
                receipt_date,
                posted_at,
                import_meta_by_bill=import_meta_by_date.get(receipt_date, {}),
            )
            posted_count += group_count
            posted_total += group_total
        set_app_meta(cursor, 'last_receipt_activity_at', max(receipt_rows_by_date.keys()))
        set_app_meta(cursor, 'last_receipt_activity_type', 'Import')
        conn.commit()
    except ValueError as exc:
        conn.rollback()
        conn.close()
        return jsonify({'success': False, 'message': str(exc)}), 400
    except Exception as exc:
        conn.rollback()
        conn.close()
        return jsonify({'success': False, 'message': f'Unable to post Tally receipts: {exc}'}), 500

    conn.close()
    return jsonify({
        'success': True,
        'message': f'{posted_count} Tally receipt(s) posted. Total: Rs {format_indian_currency(posted_total)}',
        'posted_count': posted_count,
        'posted_total': posted_total,
        'redirect_url': url_for('receipt_register')
    })

@app.route('/receipts/post', methods=['POST'])
def post_receipts():
    payload = request.get_json(silent=True) or {}
    receipt_mode = (payload.get('receipt_mode') or '').strip()
    receipt_date_obj = parse_input_date(payload.get('receipt_date') or '')
    receipt_rows = payload.get('rows') or []

    if receipt_mode not in {'Cash', 'Bank', 'Online', 'UPI'}:
        return jsonify({'success': False, 'message': 'Please select a valid receipt mode.'}), 400
    if not receipt_date_obj:
        return jsonify({'success': False, 'message': 'Please select a valid receipt date.'}), 400
    if not isinstance(receipt_rows, list) or not receipt_rows:
        return jsonify({'success': False, 'message': 'Please select at least one bill.'}), 400

    receipt_date = receipt_date_obj.strftime('%Y-%m-%d')
    posted_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    try:
        ensure_receipt_register_tally_columns(cursor)
        post_receipt_rows(cursor, receipt_rows, receipt_mode, receipt_date, posted_at)
        set_app_meta(cursor, 'last_receipt_activity_at', receipt_date)
        set_app_meta(cursor, 'last_receipt_activity_type', 'Manual')

        conn.commit()
    except ValueError as exc:
        conn.rollback()
        conn.close()
        return jsonify({'success': False, 'message': str(exc)}), 400
    except Exception as exc:
        conn.rollback()
        conn.close()
        return jsonify({'success': False, 'message': f'Unable to post receipt: {exc}'}), 500

    conn.close()
    return jsonify({'success': True, 'redirect_url': url_for('receipt_register')})

@app.route('/sub-report')
def sub_report():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    rows = get_report_rows(cursor)
    conn.close()

    followup_summary = {}
    ep_summary = {}
    category_summary = {}
    period_ep_summary = {}

    for row in rows:
        f_partner = row.get('followup_partner') or 'Unassigned'
        ep = row.get('final_ep') or 'Unassigned'
        cat = row.get('client_category') or 'Unassigned'
        fy = row.get('financial_year') or 'Unknown'
        amt = int(round(row.get('amount') or 0))

        # Aggregate Followup Summary
        followup_summary.setdefault(f_partner, {'count': 0, 'total': 0})
        followup_summary[f_partner]['count'] += 1
        followup_summary[f_partner]['total'] += amt

        # Aggregate EP Summary
        ep_summary.setdefault(ep, {'count': 0, 'total': 0})
        ep_summary[ep]['count'] += 1
        ep_summary[ep]['total'] += amt

        # Aggregate Category Summary
        category_summary.setdefault(cat, {'count': 0, 'total': 0})
        category_summary[cat]['count'] += 1
        category_summary[cat]['total'] += amt

        # Aggregate EP + Period (FY) Summary
        ep_periods = period_ep_summary.setdefault(ep, {})
        ep_periods.setdefault(fy, {'count': 0, 'total': 0})
        ep_periods[fy]['count'] += 1
        ep_periods[fy]['total'] += amt

    # Sort summaries by total amount descending
    followup_summary = dict(sorted(followup_summary.items(), key=lambda x: x[1]['total'], reverse=True))
    ep_summary = dict(sorted(ep_summary.items(), key=lambda x: x[1]['total'], reverse=True))
    category_summary = dict(sorted(category_summary.items(), key=lambda x: x[1]['total'], reverse=True))

    all_fys = sorted(list(set(row.get('financial_year') or 'Unknown' for row in rows)), reverse=True)
    all_eps = list(ep_summary.keys())

    return render_template('sub_report.html', 
                           followup_summary=followup_summary, 
                           ep_summary=ep_summary, 
                           category_summary=category_summary,
                           period_ep_summary=period_ep_summary, 
                           rows=rows,
                           active_page='sub_report',
                           all_fys=all_fys,
                           all_eps=all_eps)

@app.route('/sub-report/followup-detail')
def sub_report_followup_detail():
    partner = (request.args.get('partner') or 'Unassigned').strip() or 'Unassigned'
    return render_sub_report_detail(partner=partner)

@app.route('/sub-report/detail')
def sub_report_detail():
    return render_sub_report_detail(
        ep=(request.args.get('ep') or '').strip(),
        category=(request.args.get('category') or '').strip(),
        fy=(request.args.get('fy') or '').strip(),
        ageing=(request.args.get('ageing') or '').strip(),
    )

def due_ageing_bucket(row):
    try:
        days = int(float(row.get('overdue_days') or 0))
    except (TypeError, ValueError):
        days = 0
    days = max(0, days)
    if days <= 30:
        return '0-30 Days'
    if days <= 90:
        return '31-90 Days'
    if days <= 180:
        return '91-180 Days'
    return '180+ Days'

def filter_sub_report_rows(rows, partner='', ep='', category='', fy='', ageing=''):
    partner = (partner or '').strip()
    ep = (ep or '').strip()
    category = (category or '').strip()
    fy = (fy or '').strip()
    ageing = (ageing or '').strip()

    def normalized(value, fallback='Unassigned'):
        text = (value or fallback).strip()
        return text or fallback

    filtered_rows = []
    for row in rows:
        if partner and normalized(row.get('followup_partner')) != partner:
            continue
        if ep and normalized(row.get('final_ep')) != ep:
            continue
        if category and normalized(row.get('client_category')) != category:
            continue
        if fy and normalized(row.get('financial_year'), 'Unknown') != fy:
            continue
        if ageing and due_ageing_bucket(row) != ageing:
            continue
        filtered_rows.append(row)

    return filtered_rows

def build_sub_report_detail_title(partner='', ep='', category='', fy='', ageing=''):
    parts = []
    if partner:
        parts.append(f'Followup Partner: {partner}')
    if ep:
        parts.append(f'EP: {ep}')
    if category:
        parts.append(f'Category: {category}')
    if fy:
        parts.append(f'Financial Year: {fy}')
    if ageing:
        parts.append(f'Overdue Ageing: {ageing}')
    return ' | '.join(parts) if parts else 'Detailed Report'

def get_sub_report_detail_rows(partner='', ep='', category='', fy='', ageing=''):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    rows = get_report_rows(cursor)
    conn.close()
    return filter_sub_report_rows(rows, partner=partner, ep=ep, category=category, fy=fy, ageing=ageing)

def render_sub_report_detail(partner='', ep='', category='', fy='', ageing=''):
    partner = (partner or '').strip()
    ep = (ep or '').strip()
    category = (category or '').strip()
    fy = (fy or '').strip()
    ageing = (ageing or '').strip()

    filtered_rows = get_sub_report_detail_rows(partner=partner, ep=ep, category=category, fy=fy, ageing=ageing)
    total_amount = sum(int(round(row.get('amount') or 0)) for row in filtered_rows)
    title = build_sub_report_detail_title(partner=partner, ep=ep, category=category, fy=fy, ageing=ageing)

    return render_template(
        'sub_report_followup_detail.html',
        title=title,
        partner=partner,
        ep=ep,
        category=category,
        fy=fy,
        ageing=ageing,
        rows=filtered_rows,
        total_amount=total_amount,
        active_page='sub_report'
    )

@app.route('/sub-report/detail-excel')
def sub_report_detail_excel():
    partner = (request.args.get('partner') or '').strip()
    ep = (request.args.get('ep') or '').strip()
    category = (request.args.get('category') or '').strip()
    fy = (request.args.get('fy') or '').strip()
    ageing = (request.args.get('ageing') or '').strip()
    rows = get_sub_report_detail_rows(partner=partner, ep=ep, category=category, fy=fy, ageing=ageing)
    title = build_sub_report_detail_title(partner=partner, ep=ep, category=category, fy=fy, ageing=ageing)

    export_rows = []
    for row in rows:
        export_rows.append({
            'Date': row.get('bill_date_display') or '',
            'Ref No': row.get('ref_no') or '',
            'Party Name': row.get('party_name') or '',
            'Group': row.get('client_group') or '',
            'Category': row.get('client_category') or '',
            'Amount': row.get('amount') or 0,
            'EP': row.get('final_ep') or '',
            'Followup': row.get('followup_partner') or '',
            'FY': row.get('financial_year') or '',
        })

    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        pd.DataFrame(export_rows).to_excel(writer, index=False, sheet_name='Detailed Report')
        sheet = writer.book['Detailed Report']
        sheet.insert_rows(1, 3)
        sheet['A1'] = title
        sheet['A1'].font = Font(bold=True, size=14)
        sheet['A2'] = f'Records: {len(rows)}'
        sheet['B2'] = 'Total'
        sheet['C2'] = sum(row.get('amount') or 0 for row in rows)
        sheet['B2'].font = Font(bold=True)
        sheet['C2'].font = Font(bold=True)
        sheet.freeze_panes = 'A5'

    output.seek(0)
    filename = f"sub_report_detail_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return send_file(output, as_attachment=True, download_name=filename, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

@app.route('/periodic-report')
def periodic_report():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    rows = get_report_rows(cursor)
    conn.close()

    current_fy_str = get_current_fy_string()
    group_analysis = {} # group_name -> {'total': 0, 'fys': set()}
    ep_analysis = {}
    all_categories = set()

    for row in rows:
        fy = row.get('financial_year') or 'Unknown'
        amt = int(round(row.get('amount') or 0))
        g_name = (row.get('client_group') or row.get('party_name') or 'Unassigned').strip()
        bill_date = row.get('bill_date')
        ep = row.get('final_ep') or 'Unassigned'
        followup_partner = row.get('followup_partner') or 'Unassigned'
        cat = row.get('client_category') or 'Other'
        all_categories.add(cat)

        if g_name not in group_analysis:
            group_analysis[g_name] = {'total': 0, 'fys': set(), 'first_date': bill_date, 'followup_partners': set()}
        group_analysis[g_name]['total'] += amt
        group_analysis[g_name]['fys'].add(fy)
        if bill_date and (not group_analysis[g_name]['first_date'] or bill_date < group_analysis[g_name]['first_date']):
            group_analysis[g_name]['first_date'] = bill_date
        if followup_partner != 'Unassigned': # Only add if actually assigned
            group_analysis[g_name]['followup_partners'].add(followup_partner)
        ep_analysis[ep] = ep_analysis.get(ep, 0) + amt

    current_only_summary = {}
    prev_accum_summary = {}

    for name, data in group_analysis.items():
        has_previous = any(fy != current_fy_str for fy in data['fys'])
        
        # Determine Followup Partner display
        if len(data['followup_partners']) == 1:
            followup_partner_display = next(iter(data['followup_partners']))
        elif len(data['followup_partners']) > 1:
            followup_partner_display = 'Multiple'
        else:
            followup_partner_display = 'N/A'

        summary_item = {
            'total': data['total'],
            'first_date': format_display_date(data['first_date']),
            'followup_partner': followup_partner_display
        }
        if has_previous:
            prev_accum_summary[name] = summary_item
        elif current_fy_str in data['fys']:
            current_only_summary[name] = summary_item

    # Sort by total amount descending
    current_only_summary = dict(sorted(current_only_summary.items(), key=lambda x: x[1]['total'], reverse=True))
    prev_accum_summary = dict(sorted(prev_accum_summary.items(), key=lambda x: x[1]['total'], reverse=True))
    ep_summary = dict(sorted(ep_analysis.items(), key=lambda x: x[1], reverse=True))
    sorted_categories = sorted(list(all_categories))

    # Calculate Followup vs Category / Period Pivot Data
    current_fp_cat = {} # {fp: {cat: amt}}
    prev_fp_cat = {}
    prev_fp_period = {}

    for row in rows:
        amt = int(round(row.get('amount') or 0))
        g_name = (row.get('client_group') or row.get('party_name') or 'Unassigned').strip()
        cat = row.get('client_category') or 'Other'
        fp = row.get('followup_partner') or 'Unassigned'
        fy = row.get('financial_year') or 'Unknown'

        if g_name in current_only_summary:
            d = current_fp_cat.setdefault(fp, {})
            d[cat] = d.get(cat, 0) + amt
        elif g_name in prev_accum_summary:
            d = prev_fp_cat.setdefault(fp, {})
            d[cat] = d.get(cat, 0) + amt
            period_data = prev_fp_period.setdefault(fp, {})
            period_data[fy] = period_data.get(fy, 0) + amt

    # Sort FPs by total in their respective pivot
    current_fp_cat = dict(sorted(current_fp_cat.items(), key=lambda x: sum(x[1].values()), reverse=True))
    prev_fp_cat = dict(sorted(prev_fp_cat.items(), key=lambda x: sum(x[1].values()), reverse=True))
    prev_fp_period = dict(sorted(prev_fp_period.items(), key=lambda x: sum(x[1].values()), reverse=True))
    sorted_periods = sorted(
        {period for periods in prev_fp_period.values() for period in periods},
        reverse=True
    )
    current_fp_cat_totals = {
        cat: sum(cats.get(cat, 0) for cats in current_fp_cat.values())
        for cat in sorted_categories
    }
    prev_fp_cat_totals = {
        cat: sum(cats.get(cat, 0) for cats in prev_fp_cat.values())
        for cat in sorted_categories
    }
    prev_fp_period_totals = {
        period: sum(periods.get(period, 0) for periods in prev_fp_period.values())
        for period in sorted_periods
    }

    return render_template('periodic_report.html',
                           current_only_summary=current_only_summary,
                           prev_accum_summary=prev_accum_summary,
                           ep_summary=ep_summary,
                           current_fp_cat=current_fp_cat,
                           prev_fp_cat=prev_fp_cat,
                           prev_fp_period=prev_fp_period,
                           current_fp_cat_totals=current_fp_cat_totals,
                           prev_fp_cat_totals=prev_fp_cat_totals,
                           prev_fp_period_totals=prev_fp_period_totals,
                           all_categories=sorted_categories,
                           all_periods=sorted_periods,
                           active_page='periodic_report')

def build_report_export_data():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    rows = get_report_rows(cursor)
    conn.close()

    followup_summary = {}
    ep_summary = {}
    category_summary = {}
    period_ep_summary = {}

    for row in rows:
        f_partner = row.get('followup_partner') or 'Unassigned'
        ep = row.get('final_ep') or 'Unassigned'
        cat = row.get('client_category') or 'Unassigned'
        fy = row.get('financial_year') or 'Unknown'
        amt = int(round(row.get('amount') or 0))

        followup_summary.setdefault(f_partner, {'count': 0, 'total': 0})
        followup_summary[f_partner]['count'] += 1
        followup_summary[f_partner]['total'] += amt

        ep_summary.setdefault(ep, {'count': 0, 'total': 0})
        ep_summary[ep]['count'] += 1
        ep_summary[ep]['total'] += amt

        category_summary.setdefault(cat, {'count': 0, 'total': 0})
        category_summary[cat]['count'] += 1
        category_summary[cat]['total'] += amt

        ep_periods = period_ep_summary.setdefault(ep, {})
        ep_periods.setdefault(fy, {'count': 0, 'total': 0})
        ep_periods[fy]['count'] += 1
        ep_periods[fy]['total'] += amt

    followup_summary = dict(sorted(followup_summary.items(), key=lambda x: x[1]['total'], reverse=True))
    ep_summary = dict(sorted(ep_summary.items(), key=lambda x: x[1]['total'], reverse=True))
    category_summary = dict(sorted(category_summary.items(), key=lambda x: x[1]['total'], reverse=True))
    all_fys = sorted(list(set(row.get('financial_year') or 'Unknown' for row in rows)), reverse=True)
    all_eps = list(ep_summary.keys())

    current_fy_str = get_current_fy_string()
    group_analysis = {}
    ep_analysis = {}
    all_categories = set()

    for row in rows:
        fy = row.get('financial_year') or 'Unknown'
        amt = int(round(row.get('amount') or 0))
        g_name = (row.get('client_group') or row.get('party_name') or 'Unassigned').strip()
        bill_date = row.get('bill_date')
        ep = row.get('final_ep') or 'Unassigned'
        followup_partner = row.get('followup_partner') or 'Unassigned'
        cat = row.get('client_category') or 'Other'
        all_categories.add(cat)

        if g_name not in group_analysis:
            group_analysis[g_name] = {'total': 0, 'fys': set(), 'first_date': bill_date, 'followup_partners': set()}
        group_analysis[g_name]['total'] += amt
        group_analysis[g_name]['fys'].add(fy)
        if bill_date and (not group_analysis[g_name]['first_date'] or bill_date < group_analysis[g_name]['first_date']):
            group_analysis[g_name]['first_date'] = bill_date
        if followup_partner != 'Unassigned':
            group_analysis[g_name]['followup_partners'].add(followup_partner)
        ep_analysis[ep] = ep_analysis.get(ep, 0) + amt

    current_only_summary = {}
    prev_accum_summary = {}

    for name, data in group_analysis.items():
        has_previous = any(fy != current_fy_str for fy in data['fys'])
        if len(data['followup_partners']) == 1:
            followup_partner_display = next(iter(data['followup_partners']))
        elif len(data['followup_partners']) > 1:
            followup_partner_display = 'Multiple'
        else:
            followup_partner_display = 'N/A'

        summary_item = {
            'total': data['total'],
            'first_date': format_display_date(data['first_date']),
            'followup_partner': followup_partner_display,
        }
        if has_previous:
            prev_accum_summary[name] = summary_item
        elif current_fy_str in data['fys']:
            current_only_summary[name] = summary_item

    current_only_summary = dict(sorted(current_only_summary.items(), key=lambda x: x[1]['total'], reverse=True))
    prev_accum_summary = dict(sorted(prev_accum_summary.items(), key=lambda x: x[1]['total'], reverse=True))
    periodic_ep_summary = dict(sorted(ep_analysis.items(), key=lambda x: x[1], reverse=True))
    sorted_categories = sorted(list(all_categories))

    current_fp_cat = {}
    prev_fp_cat = {}

    for row in rows:
        amt = int(round(row.get('amount') or 0))
        g_name = (row.get('client_group') or row.get('party_name') or 'Unassigned').strip()
        cat = row.get('client_category') or 'Other'
        fp = row.get('followup_partner') or 'Unassigned'

        if g_name in current_only_summary:
            d = current_fp_cat.setdefault(fp, {})
            d[cat] = d.get(cat, 0) + amt
        elif g_name in prev_accum_summary:
            d = prev_fp_cat.setdefault(fp, {})
            d[cat] = d.get(cat, 0) + amt

    current_fp_cat = dict(sorted(current_fp_cat.items(), key=lambda x: sum(x[1].values()), reverse=True))
    prev_fp_cat = dict(sorted(prev_fp_cat.items(), key=lambda x: sum(x[1].values()), reverse=True))

    return {
        'rows': rows,
        'followup_summary': followup_summary,
        'ep_summary': ep_summary,
        'category_summary': category_summary,
        'period_ep_summary': period_ep_summary,
        'all_fys': all_fys,
        'all_eps': all_eps,
        'current_only_summary': current_only_summary,
        'prev_accum_summary': prev_accum_summary,
        'periodic_ep_summary': periodic_ep_summary,
        'current_fp_cat': current_fp_cat,
        'prev_fp_cat': prev_fp_cat,
        'all_categories': sorted_categories,
    }

def summary_export_rows(summary, name_label):
    grand_total = sum(data['total'] for data in summary.values())
    export_rows = []
    for name, data in summary.items():
        export_rows.append({
            name_label: name,
            'Total': data.get('total', 0),
            'Percent': round((data.get('total', 0) / grand_total * 100), 2) if grand_total else 0,
        })
    export_rows.append({name_label: 'Grand Total', 'Total': grand_total, 'Percent': 100 if grand_total else 0})
    return export_rows

def periodic_group_export_rows(summary, period_label=''):
    total = sum(data['total'] for data in summary.values())
    export_rows = []
    for name, data in summary.items():
        export_rows.append({
            'Period': period_label,
            'Group / Party Name': name,
            'Total': data['total'],
            'Percent': round((data['total'] / total * 100), 2) if total else 0,
            'Followup Partner': data['followup_partner'],
            'First Bill Date': data['first_date'],
        })
    export_rows.append({'Period': period_label, 'Group / Party Name': 'Grand Total', 'Total': total, 'Percent': 100 if total else 0, 'Followup Partner': '', 'First Bill Date': ''})
    return export_rows

def pivot_export_rows(pivot_data, categories, total_amount):
    export_rows = []
    for partner, cats in pivot_data.items():
        partner_total = sum(cats.values())
        row = {'Followup Partner': partner}
        for cat in categories:
            row[cat] = cats.get(cat, 0)
        row['Grand Total'] = partner_total
        row['Percent'] = round((partner_total / total_amount * 100), 2) if total_amount else 0
        export_rows.append(row)
    return export_rows

def apply_workbook_formatting(writer):
    for sheet in writer.book.worksheets:
        if not sheet.freeze_panes:
            sheet.freeze_panes = 'A2'
        for cell in sheet[1]:
            cell.font = Font(bold=True)
        for column_cells in sheet.columns:
            max_length = 10
            for cell in column_cells:
                if cell.value is not None:
                    max_length = max(max_length, len(str(cell.value)))
            sheet.column_dimensions[column_cells[0].column_letter].width = min(max_length + 2, 42)

def write_titled_sheet(writer, sheet_name, title, rows):
    pd.DataFrame(rows).to_excel(writer, index=False, sheet_name=sheet_name, startrow=2)
    sheet = writer.book[sheet_name]
    sheet['A1'] = title
    sheet['A1'].font = Font(bold=True, size=14)
    sheet.freeze_panes = 'A4'

def write_combined_summary_sheet(writer, data):
    sheet_name = 'Summaries'
    sheet = writer.book.create_sheet(sheet_name)
    current_row = 1
    sections = [
        ('Followup Summary', summary_export_rows(data['followup_summary'], 'Followup Partner')),
        ('EP Summary', summary_export_rows(data['ep_summary'], 'EP Name')),
        ('Category Summary', summary_export_rows(data['category_summary'], 'Category')),
    ]
    for title, rows in sections:
        sheet.cell(row=current_row, column=1, value=title).font = Font(bold=True, size=13)
        current_row += 1
        for row in dataframe_to_rows(pd.DataFrame(rows), index=False, header=True):
            for col_idx, value in enumerate(row, 1):
                cell = sheet.cell(row=current_row, column=col_idx, value=value)
                if current_row == 2 or sheet.cell(row=current_row - 1, column=1).value == title:
                    cell.font = Font(bold=True)
            current_row += 1
        current_row += 2

@app.route('/report/update', methods=['POST'])
def update_report_row():
    row_id = request.form.get('row_id')
    ref_no = request.form.get('ref_no', '').strip()
    party_name = request.form.get('party_name', '').strip()
    client_group = request.form.get('client_group', '').strip()
    add_to_master = request.form.get('add_to_master') == 'yes'
    bill_date_obj = parse_input_date(request.form.get('bill_date', ''))
    amount_value = request.form.get('amount', '').strip()
    ep_override = request.form.get('final_ep', '').strip()
    firm_name = request.form.get('firm_name', '').strip()

    if not row_id or not bill_date_obj or not party_name:
        flash("Unable to update row. Please check the bill date and Party's Name.")
        return redirect(url_for('index'))

    try:
        amount = float(amount_value)
    except ValueError:
        flash('Unable to update row. Please check the amount.')
        return redirect(url_for('index'))

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    short_name = get_firm_short_name(cursor, firm_name) if firm_name else None

    due_date_obj = bill_date_obj + timedelta(days=30)
    overdue_days = (datetime.now() - bill_date_obj).days

    cursor.execute('''
        SELECT client_group
        FROM client_master
        WHERE lower(trim(client_name)) = lower(trim(?))
        LIMIT 1
    ''', (party_name,))
    matching_client = cursor.fetchone()
    matching_master_group = (matching_client[0] if matching_client else '') or ''
    should_add_to_master = add_to_master and not matching_client
    group_override = client_group
    if should_add_to_master or (matching_client and matching_master_group.strip() == client_group):
        group_override = ''

    cursor.execute('''
        UPDATE billing_report
        SET ref_no = ?, bill_date = ?, party_name = ?, group_override = ?, amount = ?, due_date = ?, overdue_days = ?, ep_override = ?,
            firm_name = COALESCE(NULLIF(?, ''), firm_name),
            short_name = COALESCE(NULLIF(?, ''), short_name)
        WHERE id = ?
    ''', (
        ref_no, bill_date_obj.strftime('%Y-%m-%d'), party_name, group_override, amount, 
        due_date_obj.strftime('%Y-%m-%d'), overdue_days, ep_override,
        firm_name, short_name,
        row_id,
    ))

    if should_add_to_master:
        cursor.execute('''
            SELECT crp_of_group
            FROM client_master
            WHERE lower(trim(client_group)) = lower(trim(?))
              AND crp_of_group IS NOT NULL AND trim(crp_of_group) != ''
            GROUP BY crp_of_group
            ORDER BY COUNT(*) DESC, crp_of_group
            LIMIT 1
        ''', (client_group,))
        group_crp = cursor.fetchone()
        cursor.execute('''
            INSERT INTO client_master (client_name, client_group, crp_of_group)
            VALUES (?, ?, ?)
        ''', (party_name, client_group, group_crp[0] if group_crp else ''))

    conn.commit()
    conn.close()

    flash('Report row updated successfully.')
    return redirect(url_for('index'))

@app.route('/report/add', methods=['POST'])
def add_report_row():
    ref_no = request.form.get('ref_no', '').strip()
    party_name = request.form.get('party_name', '').strip()
    client_group = request.form.get('client_group', '').strip()
    add_to_master = request.form.get('add_to_master') == 'yes'
    bill_date_obj = parse_input_date(request.form.get('bill_date', ''))
    amount_value = request.form.get('amount', '').strip()
    ep_override = request.form.get('final_ep', '').strip()
    firm_name = request.form.get('firm_name', '').strip()

    if not firm_name or not bill_date_obj or not ref_no or not party_name:
        flash("Unable to add row. Please check firm, bill date, ref no., and Party's Name.")
        return redirect(url_for('report'))

    try:
        amount = float(amount_value)
    except ValueError:
        flash('Unable to add row. Please check the amount.')
        return redirect(url_for('report'))

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT client_group
        FROM client_master
        WHERE lower(trim(client_name)) = lower(trim(?))
        LIMIT 1
    ''', (party_name,))
    matching_client = cursor.fetchone()
    matching_master_group = (matching_client[0] if matching_client else '') or ''
    should_add_to_master = add_to_master and not matching_client
    group_override = client_group
    if should_add_to_master or (matching_client and matching_master_group.strip() == client_group):
        group_override = ''

    inserted = insert_billing_row(cursor, firm_name, bill_date_obj, ref_no, party_name, amount)
    if not inserted:
        conn.close()
        flash("Unable to add row. Please check firm, bill date, ref no., Party's Name, and amount.")
        return redirect(url_for('report'))

    row_id = cursor.lastrowid
    cursor.execute('''
        UPDATE billing_report
        SET group_override = ?, ep_override = ?
        WHERE id = ?
    ''', (group_override, ep_override, row_id))

    if should_add_to_master:
        cursor.execute('''
            SELECT crp_of_group
            FROM client_master
            WHERE lower(trim(client_group)) = lower(trim(?))
              AND crp_of_group IS NOT NULL AND trim(crp_of_group) != ''
            GROUP BY crp_of_group
            ORDER BY COUNT(*) DESC, crp_of_group
            LIMIT 1
        ''', (client_group,))
        group_crp = cursor.fetchone()
        cursor.execute('''
            INSERT INTO client_master (client_name, client_group, crp_of_group)
            VALUES (?, ?, ?)
        ''', (party_name, client_group, group_crp[0] if group_crp else ''))

    conn.commit()
    conn.close()

    flash('Report row added successfully.')
    return redirect(url_for('report'))

@app.route('/report/run-followup-logic', methods=['POST'])
def run_report_followup_logic():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    try:
        updated_count = run_followup_partner_logic(cursor)
        conn.commit()
        flash(f'Followup partner logic run successfully for {updated_count} open row(s).')
    except Exception as exc:
        conn.rollback()
        flash(f'Unable to run followup partner logic: {exc}')
    finally:
        conn.close()
    return redirect(url_for('report'))

@app.route('/download/report-excel')
def download_report_excel():
    data = build_report_export_data()
    rows = data['rows']

    export_rows = []
    for row in rows:
        export_rows.append({
            'Firm': row.get('short_name') or '',
            'Bill Date': row.get('bill_date_display') or '',
            'Ref. No.': row.get('ref_no') or '',
            "Party's Name": row.get('party_name') or '',
            'Amount': row.get('amount') or 0,
            'Due Date': row.get('due_date_display') or '',
            'Over Due': row.get('overdue_days') or 0,
            'Group': row.get('client_group') or '',
            'Followup Partner': row.get('followup_partner') or '',
            'EP': row.get('final_ep') or '',
            'CRP': row.get('crp_of_group') or '',
            'Category': row.get('client_category') or '',
            'F.Y.': row.get('financial_year') or '',
        })

    output = io.BytesIO()
    as_on_label = datetime.now().strftime('%d.%m.%Y')
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        pd.DataFrame(export_rows).to_excel(writer, index=False, sheet_name='Main Report')
        write_combined_summary_sheet(writer, data)

        ep_period_rows = []
        for fy in data['all_fys']:
            row_data = {'Financial Year': fy}
            row_total = 0
            for ep in data['all_eps']:
                amount = data['period_ep_summary'].get(ep, {}).get(fy, {'total': 0})['total']
                row_data[ep] = amount
                row_total += amount
            row_data['Total'] = row_total
            ep_period_rows.append(row_data)
        total_row = {'Financial Year': 'Grand Total'}
        grand_total = 0
        for ep in data['all_eps']:
            col_total = sum(data['period_ep_summary'].get(ep, {}).get(fy, {'total': 0})['total'] for fy in data['all_fys'])
            total_row[ep] = col_total
            grand_total += col_total
        total_row['Total'] = grand_total
        ep_period_rows.append(total_row)
        write_titled_sheet(
            writer,
            'EP Period Summary',
            f'Summary as on {as_on_label}',
            ep_period_rows
        )

        pd.DataFrame(periodic_group_export_rows(data['current_only_summary'], 'Current Period')).to_excel(writer, index=False, sheet_name='Current Period')
        writer.book['Current Period'].insert_rows(1, 2)
        writer.book['Current Period']['A1'] = 'Current Period Report'
        writer.book['Current Period']['A1'].font = Font(bold=True, size=14)
        writer.book['Current Period']['A2'] = f'Period: Current Period Only | Export as on {as_on_label}'
        writer.book['Current Period'].freeze_panes = 'A4'

        pd.DataFrame(periodic_group_export_rows(data['prev_accum_summary'], 'Previous Years')).to_excel(writer, index=False, sheet_name='Previous Years')
        writer.book['Previous Years'].insert_rows(1, 2)
        writer.book['Previous Years']['A1'] = 'Previous Years Accumulated Report'
        writer.book['Previous Years']['A1'].font = Font(bold=True, size=14)
        writer.book['Previous Years']['A2'] = f'Period: Previous Years | Export as on {as_on_label}'
        writer.book['Previous Years'].freeze_panes = 'A4'

        total_current = sum(item['total'] for item in data['current_only_summary'].values())
        total_previous = sum(item['total'] for item in data['prev_accum_summary'].values())
        pd.DataFrame(pivot_export_rows(data['current_fp_cat'], data['all_categories'], total_current)).to_excel(writer, index=False, sheet_name='Current FP Category')
        pd.DataFrame(pivot_export_rows(data['prev_fp_cat'], data['all_categories'], total_previous)).to_excel(writer, index=False, sheet_name='Previous FP Category')

        periodic_ep_rows = summary_export_rows(
            {name: {'count': 0, 'total': total} for name, total in data['periodic_ep_summary'].items()},
            'EP Name'
        )
        pd.DataFrame(periodic_ep_rows).to_excel(writer, index=False, sheet_name='Periodic EP Summary')

        apply_workbook_formatting(writer)

    output.seek(0)
    return send_file(
        output,
        download_name='debtor_reports_all_sheets.xlsx',
        as_attachment=True,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@app.route('/client-master')
def client_master_view():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM client_master')
    clients = cursor.fetchall()
    cursor.execute('''
        SELECT DISTINCT client_group
        FROM client_master
        WHERE client_group IS NOT NULL AND trim(client_group) != ''
        ORDER BY client_group
    ''')
    group_options = [row['client_group'] for row in cursor.fetchall()]
    cursor.execute('''
        SELECT client_group, crp_of_group, COUNT(*) AS use_count
        FROM client_master
        WHERE client_group IS NOT NULL AND trim(client_group) != ''
          AND crp_of_group IS NOT NULL AND trim(crp_of_group) != ''
        GROUP BY client_group, crp_of_group
        ORDER BY client_group, use_count DESC, crp_of_group
    ''')
    group_crp_map = {}
    for row in cursor.fetchall():
        group_crp_map.setdefault(row['client_group'], []).append(row['crp_of_group'])
    crp_options = sorted({crp for crp_list in group_crp_map.values() for crp in crp_list})
    conn.close()
    return render_template(
        'client_master.html',
        clients=clients,
        group_options=group_options,
        group_crp_map=group_crp_map,
        crp_options=crp_options,
    )

@app.route('/executive-partner-master')
def executive_partner_master_view():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM executive_partner_master ORDER BY partner_name')
    partners = cursor.fetchall()
    conn.close()
    return render_template('executive_partner_master.html', partners=partners)

@app.route('/firm-master')
def firm_master_view():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM firm_master ORDER BY firm_name')
    firms = cursor.fetchall()
    conn.close()
    return render_template('firm_master.html', firms=firms)

@app.route('/firm-master/add', methods=['POST'])
def add_firm():
    firm_name = request.form.get('firm_name', '').strip()
    short_name = request.form.get('short_name', '').strip() or get_short_name(firm_name)

    if not firm_name:
        flash("Firm name is required.")
        return redirect(url_for('firm_master_view'))

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    # Check for case-insensitive duplicates manually
    cursor.execute(
        'SELECT id FROM firm_master WHERE lower(trim(firm_name)) = lower(trim(?)) LIMIT 1',
        (firm_name,)
    )
    if cursor.fetchone():
        conn.close()
        flash("Firm with this name already exists.")
        return redirect(url_for('firm_master_view'))

    try:
        cursor.execute(
            'INSERT INTO firm_master (firm_name, short_name) VALUES (?, ?)',
            (firm_name, short_name)
        )
        conn.commit()
        flash("Firm added successfully!")
    except sqlite3.IntegrityError:
        flash("Firm already exists.")
    finally:
        conn.close()
    return redirect(url_for('firm_master_view'))

@app.route('/firm-master/update', methods=['POST'])
def update_firm():
    firm_id = request.form.get('firm_id')
    firm_name = request.form.get('firm_name', '').strip()
    short_name = request.form.get('short_name', '').strip() or get_short_name(firm_name)

    if not firm_id or not firm_name:
        flash("Firm name is required.")
        return redirect(url_for('firm_master_view'))

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT firm_name FROM firm_master WHERE id = ?', (firm_id,))
    old_row = cursor.fetchone()
    if not old_row:
        conn.close()
        flash("Firm not found.")
        return redirect(url_for('firm_master_view'))

    # Check if we are merging into an existing firm
    cursor.execute(
        'SELECT id, short_name FROM firm_master WHERE lower(trim(firm_name)) = lower(trim(?)) AND id != ? LIMIT 1',
        (firm_name, firm_id)
    )
    target_firm = cursor.fetchone()

    old_firm_name = old_row[0]
    try:
        if target_firm:
            # MERGE LOGIC: Move bills to target firm and delete the old master entry
            target_short = target_firm[1]
            cursor.execute(
                'UPDATE billing_report SET firm_name = ?, short_name = ? WHERE firm_name = ?',
                (firm_name, target_short, old_firm_name)
            )
            cursor.execute('DELETE FROM firm_master WHERE id = ?', (firm_id,))
            flash(f"Firm '{old_firm_name}' has been merged into '{firm_name}'. All bills updated.")
        else:
            # NORMAL RENAME
            cursor.execute(
                'UPDATE firm_master SET firm_name = ?, short_name = ? WHERE id = ?',
                (firm_name, short_name, firm_id)
            )
            cursor.execute(
                'UPDATE billing_report SET firm_name = ?, short_name = ? WHERE firm_name = ?',
                (firm_name, short_name, old_firm_name)
            )
            flash("Firm updated successfully!")
            
        conn.commit()
    except sqlite3.IntegrityError:
        flash("Firm already exists.")
    finally:
        conn.close()
    return redirect(url_for('firm_master_view'))

@app.route('/firm-master/delete', methods=['POST'])
def delete_firm():
    firm_id = request.form.get('firm_id')
    if firm_id:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('DELETE FROM firm_master WHERE id = ?', (firm_id,))
        conn.commit()
        conn.close()
        flash("Firm deleted from master. Report data was not deleted.")
    return redirect(url_for('firm_master_view'))

@app.route('/control-panel')
def control_panel():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    backups = read_backup_log()
    report_update_dates = get_manual_report_update_dates()
    return render_template(
        'control_panel.html',
        backups=backups,
        report_update_dates=report_update_dates,
        active_page='control_panel'
    )

@app.route('/control-panel/report-update', methods=['POST'])
def control_panel_report_update():
    report_as_on_date = request.form.get('report_as_on_date', '').strip()
    last_bill_update_date = request.form.get('last_bill_update_date', '').strip()
    last_receipt_update_date = request.form.get('last_receipt_update_date', '').strip()

    if (
        not parse_input_date(report_as_on_date)
        or not parse_input_date(last_bill_update_date)
        or not parse_input_date(last_receipt_update_date)
    ):
        flash('Please enter Report as on, Last Bill update, and Last Receipt update dates.')
        return redirect(url_for('control_panel'))

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    set_app_meta(cursor, 'manual_report_as_on_date', report_as_on_date)
    set_app_meta(cursor, 'manual_last_bill_update_date', last_bill_update_date)
    set_app_meta(cursor, 'manual_last_receipt_update_date', last_receipt_update_date)
    conn.commit()
    conn.close()

    flash('Report update dates saved successfully.')
    return redirect(url_for('control_panel'))

@app.route('/control-panel/navbar-access')
def debtor_navbar_access():
    users = get_debtor_users()
    saved_access = get_all_debtor_nav_access()
    for user in users:
        email = str(user.get('email') or '').lower()
        user['is_arif'] = email == 'arif.siddiqui@asija.in'
        user['access_keys'] = set(DEBTOR_NAV_ACCESS_KEYS) if user['is_arif'] else saved_access.get(email, set())
    return render_template(
        'navbar_access.html',
        users=users,
        access_items=DEBTOR_NAV_ACCESS_ITEMS,
        active_page='control_panel'
    )

@app.route('/control-panel/navbar-access/update', methods=['POST'])
def update_debtor_navbar_access():
    users = get_debtor_users()
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    ensure_debtor_nav_access_table(cursor)
    cursor.execute('DELETE FROM debtor_nav_access')

    for user in users:
        email = str(user.get('email') or '').strip().lower()
        if not email or email == 'arif.siddiqui@asija.in':
            continue
        selected_keys = request.form.getlist(f'access_{user["id"]}')
        for access_key in selected_keys:
            if access_key in DEBTOR_NAV_ACCESS_KEYS:
                cursor.execute(
                    'INSERT OR IGNORE INTO debtor_nav_access (user_email, access_key) VALUES (?, ?)',
                    (email, access_key)
                )

    conn.commit()
    conn.close()
    flash('Debtor navbar access updated successfully.')
    return redirect(url_for('debtor_navbar_access'))

@app.route('/control-panel/backup', methods=['POST'])
def control_panel_backup():
    note = request.form.get('note', '').strip() or 'Manual backup from Control Panel'
    backup_id, skipped = create_project_backup(note=note, backup_type='manual')
    if skipped:
        flash(f"Backup {backup_id} created. {len(skipped)} locked/skipped file(s).")
    else:
        flash(f"Backup {backup_id} created successfully.")
    return redirect(url_for('control_panel'))

@app.route('/control-panel/restore', methods=['POST'])
def control_panel_restore():
    backup_id = request.form.get('backup_id', '').strip()
    success, message = restore_project_backup(backup_id)
    flash(message)
    return redirect(url_for('control_panel'))

@app.route('/executive-partner-master/add', methods=['POST'])
def add_executive_partner():
    partner_name = request.form.get('partner_name', '').strip()
    final_ep = request.form.get('final_ep', '').strip()

    if partner_name:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        try:
            cursor.execute(
                'INSERT INTO executive_partner_master (partner_name, final_ep) VALUES (?, ?)',
                (partner_name, final_ep)
            )
            conn.commit()
            flash("Executive partner added successfully!")
        except sqlite3.IntegrityError:
            flash("Executive partner already exists.")
        finally:
            conn.close()
    return redirect(url_for('executive_partner_master_view'))

@app.route('/client-master/add', methods=['POST'])
def add_client():
    client_name = request.form.get('client_name')
    phone = request.form.get('phone')
    email = request.form.get('email')
    gstin = request.form.get('gstin')
    client_group = request.form.get('client_group')
    crp_of_group = request.form.get('crp_of_group')
    reffered_by = request.form.get('reffered_by')
    whatapp_group = request.form.get('whatapp_group')
    client_category = request.form.get('client_category')
    
    if client_name:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('INSERT INTO client_master (client_name, phone, email, gstin, client_group, crp_of_group, reffered_by, whatapp_group, client_category) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                       (client_name, phone, email, gstin, client_group, crp_of_group, reffered_by, whatapp_group, client_category))
        conn.commit()
        conn.close()
        flash("Client added successfully!")
    return redirect(url_for('client_master_view'))

@app.route('/client-master/update', methods=['POST'])
def update_client():
    client_id = request.form.get('client_id')
    client_name = request.form.get('client_name', '').strip()
    phone = request.form.get('phone', '').strip()
    email = request.form.get('email', '').strip()
    gstin = request.form.get('gstin', '').strip()
    client_group = request.form.get('client_group', '').strip()
    crp_of_group = request.form.get('crp_of_group', '').strip()
    reffered_by = request.form.get('reffered_by', '').strip()
    whatapp_group = request.form.get('whatapp_group', '').strip()
    client_category = request.form.get('client_category', '').strip()

    if not client_id or not client_name:
        flash("Client name is required.")
        return redirect(url_for('client_master_view'))

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE client_master
        SET client_name = ?, phone = ?, email = ?, gstin = ?, client_group = ?,
            crp_of_group = ?, reffered_by = ?, whatapp_group = ?, client_category = ?
        WHERE id = ?
    ''', (
        client_name,
        phone,
        email,
        gstin,
        client_group,
        crp_of_group,
        reffered_by,
        whatapp_group,
        client_category,
        client_id,
    ))
    conn.commit()
    conn.close()
    flash("Client updated successfully!")
    return redirect(url_for('client_master_view'))

@app.route('/download/client-list')
def download_client_list():
    """Exports the entire client master to Excel for editing."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM client_master')
    clients = cursor.fetchall()
    conn.close()

    export_rows = []
    for client in clients:
        export_rows.append({
            'ID': client['id'],
            'Client Name': client['client_name'],
            'Client Group': client['client_group'],
            'Client Category': client['client_category'],
            'CRP of Group': client['crp_of_group'],
            'Referred By': client['reffered_by'],
            'Whatapp Group': client['whatapp_group'],
            'Phone': client['phone'],
            'Email': client['email'],
            'GSTIN': client['gstin']
        })

    output = io.BytesIO()
    df = pd.DataFrame(export_rows)
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Clients')

    output.seek(0)
    return send_file(
        output,
        download_name='client_list_export.xlsx',
        as_attachment=True,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handles report upload and appends rows to the database."""
    if 'file' not in request.files:
        return redirect(request.url)
    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)
    manual_firm_name = request.form.get('firm_name', '').strip()
    
    if file and file.filename.lower().endswith(('.csv', '.xlsx', '.xls')):
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        ext = os.path.splitext(file.filename)[1].lower()
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        target_path = os.path.join(UPLOAD_DIR, f'import_{timestamp}{ext}')
        file.save(target_path)
        imported_count = process_data_file(target_path, manual_firm_name)
        flash(f"{imported_count} rows imported successfully!")
    else:
        flash("Invalid file type. Please upload .csv, .xlsx, or .xls.")
    return redirect(url_for('index'))

@app.route('/client-master/upload', methods=['POST'])
def client_master_upload():
    """Handles Excel file upload for client master, ignoring duplicates."""
    if 'file' not in request.files:
        flash("No file part in the request.", 'error')
        return redirect(url_for('client_master_view'))
    file = request.files['file']
    if file.filename == '':
        flash("No selected file.", 'error')
        return redirect(url_for('client_master_view'))
    
    if file and file.filename.endswith('.xlsx'):
        temp_path = os.path.join(BASE_DIR, 'temp_client_master.xlsx')
        file.save(temp_path)
        
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        try:
            df = pd.read_excel(temp_path)
            # Normalize column names for flexible matching
            df.columns = [str(c).strip() for c in df.columns]
            def normalize_header(header):
                return ''.join(ch for ch in str(header).lower() if ch.isalnum())

            col_map = {normalize_header(c): c for c in df.columns}

            def get_col_val(row_data, aliases):
                for alias in aliases:
                    actual_col = col_map.get(normalize_header(alias))
                    if actual_col:
                        val = row_data[actual_col]
                        return str(val).strip() if pd.notna(val) else ""
                return ""

            imported_count = 0
            for index, row in df.iterrows():
                client_id = get_col_val(row, ['ID', 'id'])
                client_name = get_col_val(row, ['Client Name', 'Name', 'Party Name', 'Party', 'Client'])
                if not client_name or client_name.lower() == 'nan': 
                    continue
                
                phone = get_col_val(row, ['Phone', 'Mobile', 'Contact', 'Phone Number'])
                email = get_col_val(row, ['Email', 'Email ID', 'Mail'])
                gstin = get_col_val(row, ['GSTIN', 'GST No', 'GST', 'GST Number'])
                client_group = get_col_val(row, ['Client Group', 'Group Name', 'Group'])
                crp_of_group = get_col_val(row, ['CRP of Group', 'CRP'])
                reffered_by = get_col_val(row, ['Reffered By', 'Referred By', 'RefferedBy', 'ReferredBy'])
                whatapp_group = get_col_val(row, ['Whatapp Group', 'Whatapp', 'Whatsapp Group', 'WhatsApp Group'])
                client_category = get_col_val(row, ['Client Category', 'Category'])
                
                if client_id:
                    # Update existing client if ID is present
                    cursor.execute('''
                        UPDATE client_master 
                        SET client_name=?, phone=?, email=?, gstin=?, client_group=?, 
                            crp_of_group=?, reffered_by=?, whatapp_group=?, client_category=?
                        WHERE id=?
                    ''', (client_name, phone, email, gstin, client_group, crp_of_group, reffered_by, whatapp_group, client_category, client_id))
                    imported_count += 1
                else:
                    # Insert as new if client name doesn't exist
                    cursor.execute('SELECT COUNT(*) FROM client_master WHERE client_name = ?', (client_name,))
                    if cursor.fetchone()[0] == 0:
                        cursor.execute('INSERT INTO client_master (client_name, phone, email, gstin, client_group, crp_of_group, reffered_by, whatapp_group, client_category) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                                       (client_name, phone, email, gstin, client_group, crp_of_group, reffered_by, whatapp_group, client_category))
                        imported_count += 1
            conn.commit()
            flash(f"{imported_count} clients processed (updated/added) successfully!", 'success')
        except Exception as e:
            flash(f"Error importing client master: {e}", 'error')
        finally:
            conn.close()
            if os.path.exists(temp_path): os.remove(temp_path) # Clean up temp file
    else:
        flash("Invalid file type. Please upload an .xlsx file.", 'error')
    return redirect(url_for('client_master_view'))

@app.route('/clear', methods=['POST'])
def clear_report():
    """Clears all data from the database and removes source data files."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM billing_report')
    conn.commit()
    conn.close()
    # Clean up source files to prevent re-import on server restart
    for name in ['data', 'input']:
        for ext in ['.csv', '.xlsx']:
            p = os.path.join(BASE_DIR, f'{name}{ext}')
            if os.path.exists(p):
                try:
                    os.remove(p)
                except OSError:
                    # File might be open in Excel; we skip deletion but the DB is already cleared
                    continue
    flash("Data deleted successfully!")
    return redirect(url_for('index'))

@app.route('/download/billing-template')
def download_billing_template():
    """Generates a template for the Billing Report."""
    output = io.BytesIO()
    # Create a DataFrame where the first row is the Firm Name placeholder
    # and the second row contains example headers or data
    data = [
        ["[Enter Your Firm Name Here]", "", "", ""],
        ["2024-01-01", "REF001", "Example Party", 5000.00]
    ]
    df = pd.DataFrame(data)
    
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, header=False)
    
    output.seek(0)
    return send_file(output, 
                     download_name="billing_template.xlsx", 
                     as_attachment=True, 
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

@app.route('/download/client-template')
def download_client_template():
    """Generates a template for the Client Master."""
    output = io.BytesIO()
    # Standard headers expected by the import logic
    df = pd.DataFrame(columns=['Client Name', 'Client Group', 'CRP of Group', 'Reffered By', 'Whatapp Group', 'Phone', 'Email', 'GSTIN'])
    
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    
    output.seek(0)
    return send_file(output, 
                     download_name="client_master_template.xlsx", 
                     as_attachment=True, 
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

try:
    init_db()
except Exception as exc:
    print(f"Debtor report database initialization skipped: {exc}")

if __name__ == '__main__':
    app.run(debug=True, port=5005)
